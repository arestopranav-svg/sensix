-- ============================================================
-- SensiX — 002_seed.sql  (SAMPLE DATA — clearly labeled demo content)
-- ============================================================

-- ── Countries (subset; expand as needed) ─────────────────────
insert into countries (code, name, dial_code, flag_emoji) values
 ('US','United States','+1','🇺🇸'), ('IN','India','+91','🇮🇳'),
 ('BR','Brazil','+55','🇧🇷'), ('ID','Indonesia','+62','🇮🇩'),
 ('PH','Philippines','+63','🇵🇭'), ('BD','Bangladesh','+880','🇧🇩'),
 ('PK','Pakistan','+92','🇵🇰'), ('NG','Nigeria','+234','🇳🇬'),
 ('MX','Mexico','+52','🇲🇽'), ('TR','Türkiye','+90','🇹🇷'),
 ('GB','United Kingdom','+44','🇬🇧'), ('DE','Germany','+49','🇩🇪'),
 ('JP','Japan','+81','🇯🇵'), ('KR','South Korea','+82','🇰🇷'),
 ('VN','Vietnam','+84','🇻🇳'), ('TH','Thailand','+66','🇹🇭'),
 ('EG','Egypt','+20','🇪🇬'), ('SA','Saudi Arabia','+966','🇸🇦'),
 ('RU','Russia','+7','🇷🇺'), ('CN','China','+86','🇨🇳'),
 ('FR','France','+33','🇫🇷'), ('ES','Spain','+34','🇪🇸'),
 ('IT','Italy','+39','🇮🇹'), ('CA','Canada','+1','🇨🇦'),
 ('AU','Australia','+61','🇦🇺'), ('AR','Argentina','+54','🇦🇷'),
 ('CO','Colombia','+57','🇨🇴'), ('MY','Malaysia','+60','🇲🇾')
on conflict (code) do nothing;

-- ── Platforms ────────────────────────────────────────────────
insert into platforms (name, slug, type) values
 ('Android','android','mobile'), ('iOS','ios','mobile'),
 ('Windows','windows','pc'), ('macOS','macos','pc'), ('Linux','linux','pc'),
 ('PlayStation','playstation','console'), ('Xbox','xbox','console'), ('Nintendo Switch','switch','console')
on conflict (slug) do nothing;

-- ── Game categories ──────────────────────────────────────────
insert into game_categories (name, slug) values
 ('Battle Royale','battle-royale'), ('FPS','fps'), ('MOBA','moba'),
 ('Racing','racing'), ('Sports','sports'), ('RPG','rpg'), ('Strategy','strategy')
on conflict (slug) do nothing;

-- ── Games (sample; publisher names informational only) ──────
insert into games (slug, name, publisher, category_id, description) values
 ('free-fire','Free Fire','Garena',(select id from game_categories where slug='battle-royale'),
  'Fast-paced mobile battle royale. Sample entry — SensiX is not affiliated with Garena.'),
 ('free-fire-max','Free Fire MAX','Garena',(select id from game_categories where slug='battle-royale'),
  'Enhanced edition of Free Fire. Sample entry — no official affiliation.'),
 ('bgmi','Battlegrounds Mobile India','Krafton',(select id from game_categories where slug='battle-royale'),
  'Indian edition of PUBG Mobile. Sample entry.'),
 ('pubg-mobile','PUBG Mobile','Level Infinite',(select id from game_categories where slug='battle-royale'),
  'Mobile battle royale by Level Infinite. Sample entry.'),
 ('cod-mobile','Call of Duty: Mobile','Activision',(select id from game_categories where slug='fps'),
  'Mobile FPS. Sample entry — no affiliation with Activision.'),
 ('new-state-mobile','NEW STATE Mobile','Krafton',(select id from game_categories where slug='battle-royale'),
  'Futuristic battle royale. Sample entry.'),
 ('mobile-legends','Mobile Legends: Bang Bang','Moonton',(select id from game_categories where slug='moba'),
  'Mobile MOBA. Sample entry.'),
 ('valorant','Valorant','Riot Games',(select id from game_categories where slug='fps'),
  'Tactical 5v5 FPS for PC. Sample entry.'),
 ('counter-strike-2','Counter-Strike 2','Valve',(select id from game_categories where slug='fps'),
  'PC FPS. Sample entry.'),
 ('pubg-pc','PUBG: Battlegrounds','Krafton',(select id from game_categories where slug='battle-royale'),
  'PC battle royale. Sample entry.'),
 ('fortnite','Fortnite','Epic Games',(select id from game_categories where slug='battle-royale'),
  'Cross-platform battle royale. Sample entry.'),
 ('apex-legends','Apex Legends','Respawn/EA',(select id from game_categories where slug='battle-royale'),
  'Squad-based battle royale. Sample entry.'),
 ('call-of-duty','Call of Duty (PC)','Activision',(select id from game_categories where slug='fps'),
  'Annual PC/console FPS franchise. Sample entry.')
on conflict (slug) do nothing;

-- Game ↔ platform links
insert into game_platforms (game_id, platform_id)
select g.id, p.id from games g, platforms p
where (g.slug in ('free-fire','free-fire-max','bgmi','pubg-mobile','cod-mobile','new-state-mobile','mobile-legends')
       and p.type = 'mobile')
   or (g.slug in ('valorant','counter-strike-2','pubg-pc','fortnite','apex-legends','call-of-duty')
       and p.type = 'pc')
   or (g.slug = 'fortnite' and p.type = 'console')
on conflict do nothing;

-- ── Device brands ────────────────────────────────────────────
insert into device_brands (name, slug) values
 ('Samsung','samsung'), ('Apple','apple'), ('Xiaomi','xiaomi'), ('Redmi','redmi'),
 ('POCO','poco'), ('OnePlus','oneplus'), ('Realme','realme'), ('OPPO','oppo'),
 ('Vivo','vivo'), ('Google','google'), ('Motorola','motorola'), ('ASUS ROG','asus-rog'),
 ('Lenovo','lenovo'), ('Infinix','infinix'), ('Tecno','tecno'), ('Huawei','huawei'),
 ('Honor','honor'), ('HP','hp'), ('Dell','dell'), ('Acer','acer'), ('MSI','msi'),
 ('ASUS','asus'), ('Lenovo Legion','lenovo-legion')
on conflict (slug) do nothing;

-- ── Devices (verified-style sample entries; unknown fields left null) ──
insert into devices (brand_id, model, slug, category, os, processor, gpu, ram_gb, storage_gb, display, refresh_rate, release_info, source_ref) values
 ((select id from device_brands where slug='samsung'),'Galaxy S23 Ultra','samsung-galaxy-s23-ultra','phone','Android 14','Snapdragon 8 Gen 2','Adreno 740',12,256,'6.8" AMOLED QHD+',120,'2023-02','https://www.samsung.com'),
 ((select id from device_brands where slug='samsung'),'Galaxy A54 5G','samsung-galaxy-a54-5g','phone','Android 14','Exynos 1380',null,8,128,'6.4" Super AMOLED',120,'2023-03',null),
 ((select id from device_brands where slug='apple'),'iPhone 15 Pro','apple-iphone-15-pro','phone','iOS 17','Apple A17 Pro','Apple GPU (6-core)',8,256,'6.1" OLED',120,'2023-09','https://www.apple.com'),
 ((select id from device_brands where slug='apple'),'iPhone 13','apple-iphone-13','phone','iOS 15','Apple A15 Bionic',null,4,128,'6.1" OLED',60,'2021-09',null),
 ((select id from device_brands where slug='redmi'),'Redmi Note 12 Pro','redmi-note-12-pro','phone','Android 13','MediaTek Dimensity 1080',null,8,256,'6.67" AMOLED',120,'2023-01',null),
 ((select id from device_brands where slug='poco'),'POCO X6 Pro','poco-x6-pro','phone','Android 14','MediaTek Dimensity 8300 Ultra',null,8,256,'6.67" AMOLED',120,'2024-01',null),
 ((select id from device_brands where slug='oneplus'),'OnePlus 11','oneplus-11','phone','Android 14','Snapdragon 8 Gen 2',null,12,256,'6.7" AMOLED',120,'2023-01',null),
 ((select id from device_brands where slug='realme'),'Realme GT Neo 5','realme-gt-neo-5','phone','Android 13','Snapdragon 8+ Gen 1',null,12,256,'6.74" AMOLED',144,'2023-02',null),
 ((select id from device_brands where slug='infinix'),'Infinix GT 10 Pro','infinix-gt-10-pro','phone','Android 13','MediaTek Dimensity 8050',null,8,256,'6.67" AMOLED',120,'2023-08',null),
 ((select id from device_brands where slug='tecno'),'Tecno Pova 5','tecno-pova-5','phone','Android 13','MediaTek Helio G99',null,8,128,'6.78" IPS LCD',120,'2023-06',null),
 ((select id from device_brands where slug='asus-rog'),'ROG Phone 7','asus-rog-phone-7','phone','Android 13','Snapdragon 8 Gen 2','Adreno 740',12,256,'6.78" AMOLED',165,'2023-04','https://rog.asus.com'),
 ((select id from device_brands where slug='google'),'Pixel 8 Pro','google-pixel-8-pro','phone','Android 14','Google Tensor G3',null,12,128,'6.7" LTPO OLED',120,'2023-10',null),
 ((select id from device_brands where slug='samsung'),'Galaxy Tab S9','samsung-galaxy-tab-s9','tablet','Android 13','Snapdragon 8 Gen 2',null,8,128,'11" AMOLED',120,'2023-08',null),
 ((select id from device_brands where slug='apple'),'iPad Pro 11 (2022)','apple-ipad-pro-11-2022','tablet','iPadOS 16','Apple M2',null,8,128,'11" Liquid Retina',120,'2022-10',null),
 ((select id from device_brands where slug='asus-rog'),'ROG Strix G16 (2023)','asus-rog-strix-g16-2023','laptop','Windows 11','Intel Core i7-13650HX','RTX 4060 Laptop',16,1024,'16" IPS FHD+',165,'2023-04','https://rog.asus.com'),
 ((select id from device_brands where slug='lenovo-legion'),'Legion 5 Pro (2023)','lenovo-legion-5-pro-2023','laptop','Windows 11','AMD Ryzen 7 7745HX','RTX 4070 Laptop',16,1024,'16" WQXGA',240,'2023-05',null),
 ((select id from device_brands where slug='msi'),'Katana 15 (2023)','msi-katana-15-2023','laptop','Windows 11','Intel Core i7-13620H','RTX 4060 Laptop',16,1024,'15.6" FHD',144,'2023-03',null),
 ((select id from device_brands where slug='hp'),'Victus 15 (2023)','hp-victus-15-2023','laptop','Windows 11','Intel Core i5-12450H','RTX 3050 Laptop',8,512,'15.6" FHD',144,'2023-01',null),
 ((select id from device_brands where slug='dell'),'G15 5530','dell-g15-5530','laptop','Windows 11','Intel Core i7-13650HX','RTX 4050 Laptop',16,512,'15.6" FHD',165,'2023-04',null),
 ((select id from device_brands where slug='acer'),'Nitro 5 (2023)','acer-nitro-5-2023','laptop','Windows 11','AMD Ryzen 7 7735HS','RTX 4050 Laptop',16,512,'15.6" FHD',144,'2023-02',null)
on conflict (slug) do nothing;

-- ── Sample settings profiles (verified + community) ─────────
insert into game_settings
  (game_id, device_id, platform_id, title, category, values, control_type, gyroscope, game_version, source_name, is_verified)
select
 g.id, d.id, p.id, title, cat, vals::jsonb, ctype, gyro, ver, src, verified
from (values
  ('free-fire', null, 'android', 'Free Fire MAX — Universal Sensitivity (Sample)', 'sensitivity',
   '{"general":100,"red_dot":95,"2x_scope":90,"4x_scope":80,"sniper_scope":50,"free_look":70}', 'touch', false, 'OB48', 'SensiX Team', true),
  ('free-fire', 'samsung-galaxy-s23-ultra', 'android', 'Galaxy S23 Ultra — Headshot Sensitivity (Sample)', 'sensitivity',
   '{"general":98,"red_dot":92,"2x_scope":88,"4x_scope":78,"sniper_scope":45,"free_look":66}', 'touch', true, 'OB48', 'SensiX Team', true),
  ('free-fire', null, 'android', 'Free Fire — Smooth Graphics + 60 FPS (Sample)', 'graphics',
   '{"graphics":"Smooth","fps":"High","shadows":false,"auto_adjust":false}', 'touch', null, 'OB48', 'SensiX Team', true),
  ('bgmi', 'apple-iphone-15-pro', 'ios', 'iPhone 15 Pro — BGMI 3-Finger Claw (Sample)', 'sensitivity',
   '{"camera":{"tpp":120,"fpp":110,"red_dot":55,"2x":40,"3x":30,"4x":25,"6x":15,"8x":10},"ads":{"tpp":95,"fpp":90,"red_dot":45,"2x":30,"3x":22,"4x":18,"6x":12,"8x":8},"gyro":{"tpp":300,"fpp":300,"red_dot":300,"2x":300,"3x":250,"4x":220,"6x":150,"8x":100}}', 'touch', true, '3.4', 'SensiX Team', true),
  ('bgmi', null, 'android', 'BGMI — Low-End Device Graphics (Sample)', 'graphics',
   '{"graphics":"Smooth","fps":"Extreme","brightness":100,"style":"Colorful","shadows":false}', 'touch', null, '3.4', 'Community', false),
  ('pubg-mobile', 'poco-x6-pro', 'android', 'POCO X6 Pro — PUBG Mobile 4-Finger (Sample)', 'sensitivity',
   '{"camera":{"tpp":125,"fpp":115,"red_dot":60,"2x":42,"3x":32,"4x":26,"6x":16,"8x":12},"ads":{"tpp":98,"fpp":92,"red_dot":48,"2x":32,"3x":24,"4x":20,"6x":13,"8x":9}}', 'touch', false, '3.4', 'Community', false),
  ('cod-mobile', 'apple-iphone-13', 'ios', 'iPhone 13 — COD Mobile MP Sensitivity (Sample)', 'sensitivity',
   '{"standard":90,"ads":{"red_dot":55,"tactical":50,"sniper":35,"mla":45}}', 'touch', false, '1.0.44', 'Community', false),
  ('valorant', null, 'windows', 'Valorant — 800 DPI Entry Fragger (Sample)', 'sensitivity',
   '{"dpi":800,"sensitivity":0.35,"scoped_sensitivity":1.0,"eDpi":280,"zoom_sensitivity":1.0,"raw_input":true}', 'mouse', null, '8.11', 'SensiX Team', true),
  ('counter-strike-2', null, 'windows', 'CS2 — 400 DPI Rifler (Sample)', 'sensitivity',
   '{"dpi":400,"sensitivity":2.0,"eDpi":800,"zoom_sensitivity":1.0,"raw_input":true,"crosshair":"CSGO-XXXXX-XXXXX-XXXXX (sample)"}', 'mouse', null, '1.40', 'SensiX Team', true),
  ('fortnite', null, 'windows', 'Fortnite — 1600 DPI Builder (Sample)', 'sensitivity',
   '{"dpi":1600,"x_sensitivity":8.5,"y_sensitivity":8.5,"targeting":45,"scope":45,"building_edit":9.0}', 'mouse', null, '31.00', 'Community', false)
 ) as t(game_slug, device_slug, platform_slug, title, cat, vals, ctype, gyro, ver, src, verified)
join games g on g.slug = t.game_slug
join platforms p on p.slug = t.platform_slug
left join devices d on d.slug = t.device_slug
on conflict do nothing;

-- ── Default role permissions ─────────────────────────────────
insert into admin_permissions (role, module, can_read, can_write) values
 -- super_admin: full access everywhere (checked implicitly in app)
 ('admin','games',true,true), ('admin','devices',true,true), ('admin','settings',true,true),
 ('admin','submissions',true,true), ('admin','users',true,true),
 ('admin','content',true,true), ('admin','analytics',true,false), ('admin','settings_admin',true,true),
 ('moderator','submissions',true,true), ('moderator','settings',true,true),
 ('moderator','games',true,false), ('moderator','devices',true,false), ('moderator','analytics',true,false),
 ('editor','games',true,true), ('editor','devices',true,true),
 ('editor','content',true,true), ('editor','settings',true,true), ('editor','analytics',true,false)
on conflict (role, module) do nothing;

-- ── Homepage banner + announcement (sample) ─────────────────
insert into banners (title, subtitle, link_url, position, sort_order) values
 ('Find your perfect sensitivity','Hand-tested settings for every device and game. Sample banner.','/games','home_hero',0)
on conflict do nothing;

insert into announcements (title, body) values
 ('Welcome to SensiX (Beta)','This is sample content. SensiX is an independent platform and is not affiliated with any game publisher.')
on conflict do nothing;
