-- ============================================================
-- SensiX — 001_schema.sql
-- Normalized PostgreSQL schema with RLS, indexes, constraints,
-- audit triggers and safe-deletion policies.
-- Apply via: supabase db push   (or paste into Supabase SQL editor)
-- ============================================================

create extension if not exists "pgcrypto";

-- ── Countries ────────────────────────────────────────────────
create table if not exists countries (
  id          uuid primary key default gen_random_uuid(),
  code        char(2) not null unique,          -- ISO 3166-1 alpha-2
  name        text not null,
  dial_code   text not null,                    -- e.g. +91
  flag_emoji  text,
  created_at  timestamptz not null default now()
);

-- ── Platforms (Android / iOS / Windows / macOS / Linux / Console) ──
create table if not exists platforms (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  slug        text not null unique,
  type        text not null check (type in ('mobile','pc','console')),
  created_at  timestamptz not null default now()
);

-- ── Game categories ──────────────────────────────────────────
create table if not exists game_categories (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  slug        text not null unique,
  created_at  timestamptz not null default now()
);

-- ── Games ────────────────────────────────────────────────────
create table if not exists games (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique,
  name         text not null,
  publisher    text,                            -- informational only; no affiliation claimed
  category_id  uuid references game_categories(id) on delete set null,
  description  text,
  cover_url    text,
  is_active    boolean not null default true,
  views        bigint not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists games_category_idx on games(category_id);
create index if not exists games_name_trgm on games using gin (to_tsvector('simple', name));

create table if not exists game_platforms (
  game_id     uuid not null references games(id) on delete cascade,
  platform_id uuid not null references platforms(id) on delete cascade,
  primary key (game_id, platform_id)
);

-- ── Device brands ────────────────────────────────────────────
create table if not exists device_brands (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  slug        text not null unique,
  created_at  timestamptz not null default now()
);

-- ── Devices (one row per exact model) ───────────────────────
create table if not exists devices (
  id            uuid primary key default gen_random_uuid(),
  brand_id      uuid not null references device_brands(id) on delete restrict,
  model         text not null,                  -- exact model name
  slug          text not null unique,
  category      text not null check (category in ('phone','tablet','laptop','desktop','console','other')),
  os            text,                           -- e.g. "Android 14"
  processor     text,                           -- null = unknown, never invented
  gpu           text,
  ram_gb        numeric(6,2),
  storage_gb    numeric(7,1),
  display       text,
  refresh_rate  integer,                        -- Hz
  release_info  text,
  source_ref    text,                           -- manufacturer/spec-sheet reference URL
  is_active     boolean not null default true,
  views         bigint not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (brand_id, model)                      -- duplicate prevention
);
create index if not exists devices_brand_idx on devices(brand_id);
create index if not exists devices_category_idx on devices(category);

-- ── Settings profiles ───────────────────────────────────────
-- Flexible by design: each game defines its own category set via
-- game_settings.category (free-form, validated at app level per game),
-- and the actual values live in `values` (jsonb) + typed settings_values rows.
create table if not exists game_settings (
  id             uuid primary key default gen_random_uuid(),
  game_id        uuid not null references games(id) on delete cascade,
  device_id      uuid references devices(id) on delete set null,
  platform_id    uuid not null references platforms(id) on delete restrict,
  title          text not null,
  category       text not null,                 -- e.g. "sensitivity", "graphics", "crosshair"
  values         jsonb not null default '{}'::jsonb,  -- game-specific shape
  control_type   text check (control_type in ('touch','mouse','controller', null)),
  gyroscope      boolean,                       -- null where not applicable
  game_version   text,
  author_id      uuid references profiles(id) on delete set null,
  source_name    text,                          -- author / source attribution
  is_verified    boolean not null default false,
  is_published   boolean not null default true,
  disclaimer_ack boolean not null default true, -- "not guaranteed to improve performance"
  views          bigint not null default 0,
  avg_rating     numeric(3,2) not null default 0,
  rating_count   integer not null default 0,
  version        integer not null default 1,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists gs_game_idx    on game_settings(game_id)   where is_published;
create index if not exists gs_device_idx  on game_settings(device_id) where is_published;
create index if not exists gs_search_idx  on game_settings using gin (to_tsvector('simple', title));

-- ── Typed key/value rows mirrored from `values` for filtering ──
create table if not exists settings_values (
  id          uuid primary key default gen_random_uuid(),
  settings_id uuid not null references game_settings(id) on delete cascade,
  key         text not null,
  value       text not null,
  numeric_val numeric,
  unique (settings_id, key)
);
create index if not exists sv_settings_idx on settings_values(settings_id);

-- ── Version history ─────────────────────────────────────────
create table if not exists settings_versions (
  id          uuid primary key default gen_random_uuid(),
  settings_id uuid not null references game_settings(id) on delete cascade,
  version     integer not null,
  values      jsonb not null,
  changed_by  uuid references profiles(id) on delete set null,
  notes       text,
  created_at  timestamptz not null default now(),
  unique (settings_id, version)
);

-- ── Profiles (extends Supabase auth.users) ──────────────────
create table if not exists profiles (
  id                   uuid primary key references auth.users(id) on delete cascade,
  username             text unique check (char_length(username) between 3 and 30),
  email                text not null,
  country_id           uuid references countries(id) on delete set null,
  preferred_platform_id uuid references platforms(id) on delete set null,
  avatar_url           text,
  role                 text not null default 'user'
                       check (role in ('user','editor','moderator','admin','super_admin')),
  suspended            boolean not null default false,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now()
);
create index if not exists profiles_username_idx on profiles(username);

-- ── Favourites (polymorphic) ────────────────────────────────
create table if not exists user_favourites (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  target_type text not null check (target_type in ('game','device','settings')),
  target_id   uuid not null,
  created_at  timestamptz not null default now(),
  unique (user_id, target_type, target_id)
);

-- ── Saved settings ──────────────────────────────────────────
create table if not exists saved_settings (
  user_id      uuid not null references profiles(id) on delete cascade,
  settings_id  uuid not null references game_settings(id) on delete cascade,
  created_at   timestamptz not null default now(),
  primary key (user_id, settings_id)
);

-- ── Recently viewed ─────────────────────────────────────────
create table if not exists recently_viewed (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  target_type text not null check (target_type in ('game','device','settings')),
  target_id   uuid not null,
  viewed_at   timestamptz not null default now(),
  unique (user_id, target_type, target_id)
);

-- ── User submissions ────────────────────────────────────────
create table if not exists user_submissions (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references profiles(id) on delete cascade,
  game_id     uuid not null references games(id) on delete cascade,
  device_id   uuid references devices(id) on delete set null,
  platform_id uuid not null references platforms(id) on delete restrict,
  title       text not null,
  category    text not null,
  values      jsonb not null default '{}'::jsonb,
  control_type text check (control_type in ('touch','mouse','controller', null)),
  gyroscope   boolean,
  game_version text,
  status      text not null default 'pending'
              check (status in ('pending','approved','rejected','needs_changes')),
  admin_notes text,
  reviewed_by uuid references profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists us_status_idx on user_submissions(status) where status = 'pending';

-- ── Submission reviews ──────────────────────────────────────
create table if not exists submission_reviews (
  id            uuid primary key default gen_random_uuid(),
  submission_id uuid not null references user_submissions(id) on delete cascade,
  reviewer_id   uuid not null references profiles(id) on delete cascade,
  action        text not null check (action in ('approve','reject','request_changes')),
  notes         text,
  created_at    timestamptz not null default now()
);

-- ── Ratings ─────────────────────────────────────────────────
create table if not exists settings_ratings (
  user_id     uuid not null references profiles(id) on delete cascade,
  settings_id uuid not null references game_settings(id) on delete cascade,
  rating      integer not null check (rating between 1 and 5),
  created_at  timestamptz not null default now(),
  primary key (user_id, settings_id)
);

-- ── Admin permissions (role → module grants) ────────────────
create table if not exists admin_permissions (
  role    text not null check (role in ('editor','moderator','admin','super_admin')),
  module  text not null,                        -- e.g. 'games','devices','submissions','users','content','analytics','settings','admins'
  can_read   boolean not null default true,
  can_write  boolean not null default false,
  primary key (role, module)
);

-- ── Audit logs ──────────────────────────────────────────────
create table if not exists audit_logs (
  id          bigint generated always as identity primary key,
  actor_id    uuid references profiles(id) on delete set null,
  action      text not null,                    -- e.g. 'settings.publish','user.suspend'
  entity      text,
  entity_id   text,
  metadata    jsonb not null default '{}'::jsonb,
  ip          inet,
  created_at  timestamptz not null default now()
);
create index if not exists audit_logs_actor_idx on audit_logs(actor_id);
create index if not exists audit_logs_created_idx on audit_logs(created_at desc);

-- ── CMS ─────────────────────────────────────────────────────
create table if not exists announcements (
  id         uuid primary key default gen_random_uuid(),
  title      text not null,
  body       text not null,
  is_active  boolean not null default true,
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists banners (
  id         uuid primary key default gen_random_uuid(),
  title      text not null,
  subtitle   text,
  image_url  text,
  link_url   text,
  position   text not null default 'home_hero',
  sort_order integer not null default 0,
  is_active  boolean not null default true,
  created_at timestamptz not null default now()
);

-- ── Analytics events ────────────────────────────────────────
create table if not exists analytics_events (
  id         bigint generated always as identity primary key,
  event      text not null,                     -- page_view, search, game_view, device_view...
  path       text,
  entity     text,
  entity_id  text,
  country_code char(2),
  user_id    uuid references profiles(id) on delete set null,
  session_id text,
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists ae_event_idx on analytics_events(event, created_at desc);
create index if not exists ae_created_idx on analytics_events(created_at desc);

-- ══════════════ Helpers & triggers ══════════════

-- Security definer: checks the caller's role without recursive RLS.
create or replace function public.current_user_role()
returns text language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid()
$$;

create or replace function public.has_role(roles text[])
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role from profiles where id = auth.uid()) = any(roles), false)
    and not coalesce((select suspended from profiles where id = auth.uid()), true)
$$;

create or replace function public.is_suspended()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select suspended from profiles where id = auth.uid()), true)
$$;

-- Auto-create profile on signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, username)
  values (new.id, new.email,
          lower(regexp_replace(coalesce(new.raw_user_meta_data->>'full_name','gamer'), '[^a-zA-Z0-9]', '', 'g'))
          || substr(new.id::text, 1, 6));
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Keep updated_at fresh.
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

do $$
declare t text;
begin
  foreach t in array array['games','devices','game_settings','profiles','user_submissions']
  loop
    execute format('drop trigger if exists trg_touch_%s on %I; create trigger trg_touch_%s before update on %I for each row execute function public.touch_updated_at();', t, t, t, t);
  end loop;
end $$;

-- Generic audit writer (called from app with service role or by admins).
create or replace function public.write_audit(
  p_action text, p_entity text default null, p_entity_id text default null,
  p_metadata jsonb default '{}'::jsonb, p_ip inet default null
) returns void language sql security definer set search_path = public as $$
  insert into audit_logs (actor_id, action, entity, entity_id, metadata, ip)
  values (auth.uid(), p_action, p_entity, p_entity_id, p_metadata, p_ip)
$$;

-- ══════════════ ROW LEVEL SECURITY ══════════════

alter table countries         enable row level security;
alter table platforms         enable row level security;
alter table game_categories   enable row level security;
alter table games             enable row level security;
alter table game_platforms    enable row level security;
alter table device_brands     enable row level security;
alter table devices           enable row level security;
alter table game_settings     enable row level security;
alter table settings_values   enable row level security;
alter table settings_versions enable row level security;
alter table profiles          enable row level security;
alter table user_favourites   enable row level security;
alter table saved_settings    enable row level security;
alter table recently_viewed   enable row level security;
alter table user_submissions  enable row level security;
alter table submission_reviews enable row level security;
alter table settings_ratings  enable row level security;
alter table admin_permissions enable row level security;
alter table audit_logs        enable row level security;
alter table announcements     enable row level security;
alter table banners           enable row level security;
alter table analytics_events  enable row level security;

-- Public read
create policy "public read countries"       on countries         for select using (true);
create policy "public read platforms"       on platforms         for select using (true);
create policy "public read categories"      on game_categories  for select using (true);
create policy "public read games"           on games             for select using (is_active or has_role('{editor,moderator,admin,super_admin}'));
create policy "public read game_platforms"  on game_platforms   for select using (true);
create policy "public read brands"          on device_brands    for select using (true);
create policy "public read devices"         on devices           for select using (is_active or has_role('{editor,moderator,admin,super_admin}'));
create policy "public read published settings" on game_settings  for select using (is_published or author_id = auth.uid() or has_role('{editor,moderator,admin,super_admin}'));
create policy "public read settings_values" on settings_values  for select using (true);
create policy "public read settings_versions" on settings_versions for select using (true);
create policy "public read announcements"   on announcements     for select using (is_active or has_role('{editor,moderator,admin,super_admin}'));
create policy "public read banners"         on banners           for select using (is_active or has_role('{editor,moderator,admin,super_admin}'));

-- Profiles: public can view basic profile, only owner edits own row
create policy "public read profiles"  on profiles for select using (true);
create policy "own profile update"    on profiles for update using (auth.uid() = id and not public.is_suspended())
  with check (auth.uid() = id and not public.is_suspended() and role = public.current_user_role());
-- The with-check above prevents self-promotion: role must equal existing role.

-- Auth-only tables
create policy "fav owner all"        on user_favourites   for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "saved owner all"      on saved_settings    for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "recent owner all"     on recently_viewed   for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "ratings owner all"    on settings_ratings for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Submissions: users manage their own; moderators+ read all and review
create policy "sub own select"  on user_submissions for select using (auth.uid() = user_id or has_role('{moderator,admin,super_admin}'));
create policy "sub own insert"  on user_submissions for insert with check (auth.uid() = user_id and status = 'pending');
create policy "sub own update"  on user_submissions for update using (auth.uid() = user_id and status = 'pending') with check (auth.uid() = user_id and status = 'pending');
create policy "sub mod update"  on user_submissions for update using (has_role('{moderator,admin,super_admin}')) with check (has_role('{moderator,admin,super_admin}'));
create policy "reviews mod read"   on submission_reviews for select using (has_role('{moderator,admin,super_admin}'));
create policy "reviews mod insert" on submission_reviews for insert with check (has_role('{moderator,admin,super_admin}'));

-- Staff-only tables
create policy "audit admin read" on audit_logs for select using (has_role('{admin,super_admin}'));
create policy "perms staff read" on admin_permissions for select using (has_role('{editor,moderator,admin,super_admin}'));
create policy "perms super write" on admin_permissions for all using (has_role('{super_admin}')) with check (has_role('{super_admin}'));

-- Staff write access to content (role granularity enforced in app via admin_permissions)
create policy "games staff write"      on games for all      using (has_role('{editor,moderator,admin,super_admin}')) with check (has_role('{editor,moderator,admin,super_admin}'));
create policy "platforms staff write"  on platforms for all  using (has_role('{admin,super_admin}')) with check (has_role('{admin,super_admin}'));
create policy "categories staff write" on game_categories for all using (has_role('{editor,admin,super_admin}')) with check (has_role('{editor,admin,super_admin}'));
create policy "brands staff write"     on device_brands for all using (has_role('{editor,moderator,admin,super_admin}')) with check (has_role('{editor,moderator,admin,super_admin}'));
create policy "devices staff write"    on devices for all    using (has_role('{editor,moderator,admin,super_admin}')) with check (has_role('{editor,moderator,admin,super_admin}'));
create policy "settings staff write"   on game_settings for all using (has_role('{editor,moderator,admin,super_admin}')) with check (has_role('{editor,moderator,admin,super_admin}'));
create policy "settings_values staff write" on settings_values for all using (has_role('{editor,moderator,admin,super_admin}')) with check (has_role('{editor,moderator,admin,super_admin}'));
create policy "settings_versions staff write" on settings_versions for all using (has_role('{editor,moderator,admin,super_admin}')) with check (has_role('{editor,moderator,admin,super_admin}'));
create policy "announcements staff write" on announcements for all using (has_role('{editor,admin,super_admin}')) with check (has_role('{editor,admin,super_admin}'));
create policy "banners staff write"      on banners for all using (has_role('{editor,admin,super_admin}')) with check (has_role('{editor,admin,super_admin}'));

-- Analytics: anyone (incl. anon) can insert events; only staff read
create policy "analytics insert" on analytics_events for insert with check (true);
create policy "analytics staff read" on analytics_events for select using (has_role('{editor,moderator,admin,super_admin}'));

-- Users: admins manage profiles (suspend etc.)
create policy "profiles admin all" on profiles for all
  using (has_role('{admin,super_admin}'))
  with check (has_role('{admin,super_admin}') and (role is distinct from 'super_admin' or public.current_user_role() = 'super_admin'));
