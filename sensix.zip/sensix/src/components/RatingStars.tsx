"use client"
import { useState } from 'react'
import { Star } from 'lucide-react'

export default function RatingStars({ settingsId, initial }: { settingsId: string; initial: number }) {
  const [value, setValue] = useState(initial)
  const [hover, setHover] = useState(0)
  const rate = async (n: number) => {
    setValue(n)
    await fetch('/api/settings/' + settingsId + '/rate', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating: n }),
    })
  }
  return (
    <div className="flex items-center gap-1" role="radiogroup" aria-label="Rate this profile">
      {[1, 2, 3, 4, 5].map((n) => (
        <button key={n} role="radio" aria-checked={value === n} aria-label={`${n} star${n > 1 ? 's' : ''}`}
          onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(0)} onClick={() => rate(n)}>
          <Star className={`h-5 w-5 ${(hover || value) >= n ? 'fill-amber-400 text-amber-400' : 'text-gray-300'}`} />
        </button>
      ))}
    </div>
  )
}
