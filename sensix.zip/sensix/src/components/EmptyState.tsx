import { SearchX } from 'lucide-react'

export default function EmptyState({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-gray-300 py-16 text-center dark:border-gray-700">
      <SearchX className="h-10 w-10 text-gray-300 dark:text-gray-600" />
      <p className="mt-3 font-medium text-gray-700 dark:text-gray-200">{title}</p>
      {hint && <p className="mt-1 text-sm text-gray-400">{hint}</p>}
    </div>
  )
}
