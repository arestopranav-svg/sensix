import Link from 'next/link'
import { Trophy } from 'lucide-react'

export default function GameCard({ game }: { game: any }) {
  return (
    <Link href={`/games/${game.slug}`}
      className="group rounded-2xl border border-gray-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md dark:border-gray-800 dark:bg-gray-900 dark:hover:border-brand-700">
      <div className="flex items-start justify-between">
        <h3 className="font-semibold text-gray-900 group-hover:text-brand-600 dark:text-gray-100">{game.name}</h3>
        {game.game_settings?.[0]?.count > 0 && (
          <span className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-2 py-0.5 text-xs font-medium text-brand-700 dark:bg-brand-900/40 dark:text-brand-300">
            <Trophy className="h-3 w-3" /> {game.game_settings[0].count}
          </span>
        )}
      </div>
      <p className="mt-1 text-sm text-gray-500 dark:text-gray-400 line-clamp-2">{game.description ?? game.game_categories?.name}</p>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {game.game_platforms?.map((gp: any) => (
          <span key={gp.platforms.id} className="rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-gray-800 dark:text-gray-300">
            {gp.platforms.name}
          </span>
        ))}
      </div>
    </Link>
  )
}
