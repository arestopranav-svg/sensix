"use client"
import { useState } from 'react'
import { Bookmark } from 'lucide-react'

export default function SaveButton({ settingsId, initial }: { settingsId: string; initial: boolean }) {
  const [on, setOn] = useState(initial)
  const toggle = async () => {
    const res = await fetch('/api/saved', {
      method: on ? 'DELETE' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings_id: settingsId }),
    })
    if (res.ok) setOn(!on)
  }
  return (
    <button onClick={toggle}
      className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold ${on ? 'border-brand-300 text-brand-600 bg-brand-50 dark:bg-brand-900/20' : 'border-gray-300 text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300'}`}>
      <Bookmark className={`h-4 w-4 ${on ? 'fill-brand-500 text-brand-500' : ''}`} /> {on ? 'Saved' : 'Save'}
    </button>
  )
}
