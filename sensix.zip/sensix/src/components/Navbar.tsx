import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import { isStaff } from '@/lib/auth'
import MobileNav from './MobileNav'
import ThemeToggle from './ThemeToggle'
import { Gamepad2 } from 'lucide-react'

export default async function Navbar() {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  let role = null
  if (user) {
    const { data } = await supabase.from('profiles').select('role').eq('id', user.id).single()
    role = data?.role ?? null
  }

  const links = [
    { href: '/games', label: 'Games' },
    { href: '/devices', label: 'Devices' },
    { href: '/search', label: 'Search' },
  ]

  return (
    <header className="sticky top-0 z-40 border-b border-gray-200 bg-white/80 backdrop-blur dark:border-gray-800 dark:bg-gray-950/80">
      <nav className="mx-auto flex h-14 max-w-7xl items-center gap-4 px-4">
        <Link href="/" className="flex items-center gap-2 font-bold text-brand-600">
          <Gamepad2 className="h-6 w-6" />
          <span className="text-lg tracking-tight">SensiX</span>
        </Link>
        <div className="hidden items-center gap-1 md:flex">
          {links.map((l) => (
            <Link key={l.href} href={l.href}
              className="rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-800">
              {l.label}
            </Link>
          ))}
        </div>
        <div className="ml-auto flex items-center gap-2">
          <ThemeToggle />
          {user ? (
            <>
              <Link href="/dashboard"
                className="hidden rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 md:block dark:text-gray-300 dark:hover:bg-gray-800">
                Dashboard
              </Link>
              {isStaff(role) && (
                <Link href="/admin"
                  className="hidden rounded-lg bg-brand-50 px-3 py-2 text-sm font-medium text-brand-700 hover:bg-brand-100 md:block dark:bg-brand-900/30 dark:text-brand-300">
                  Admin
                </Link>
              )}
              <form action="/auth/signout" method="post">
                <button className="rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
                  Sign out
                </button>
              </form>
            </>
          ) : (
            <>
              <Link href="/login" className="rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">Log in</Link>
              <Link href="/signup" className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white hover:bg-brand-700">
                Sign up
              </Link>
            </>
          )}
          <MobileNav links={links} isSignedIn={!!user} isStaff={isStaff(role)} />
        </div>
      </nav>
    </header>
  )
}
