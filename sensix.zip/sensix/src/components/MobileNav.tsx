"use client"
import Link from 'next/link'
import { useState } from 'react'
import { Menu, X } from 'lucide-react'

export default function MobileNav({ links, isSignedIn, isStaff }: {
  links: { href: string; label: string }[]
  isSignedIn: boolean; isStaff: boolean
}) {
  const [open, setOpen] = useState(false)
  return (
    <div className="md:hidden">
      <button onClick={() => setOpen(!open)} aria-label="Toggle menu"
        className="rounded-lg p-2 text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">
        {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
      </button>
      {open && (
        <div className="absolute inset-x-0 top-14 border-b border-gray-200 bg-white shadow-lg dark:border-gray-800 dark:bg-gray-950">
          <div className="flex flex-col p-4 gap-1">
            {links.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-800">
                {l.label}
              </Link>
            ))}
            {isSignedIn && (
              <>
                <Link href="/dashboard" onClick={() => setOpen(false)}
                  className="rounded-lg px-3 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-100 dark:text-gray-200 dark:hover:bg-gray-800">Dashboard</Link>
                {isStaff && (
                  <Link href="/admin" onClick={() => setOpen(false)}
                    className="rounded-lg px-3 py-2.5 text-sm font-medium text-brand-700 hover:bg-brand-50 dark:text-brand-300">Admin Panel</Link>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
