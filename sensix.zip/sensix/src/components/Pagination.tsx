import Link from 'next/link'

export default function Pagination({ page, totalPages, basePath, params = {} }: {
  page: number; totalPages: number; basePath: string; params?: Record<string, string>
}) {
  if (totalPages <= 1) return null
  const qs = (p: number) => {
    const sp = new URLSearchParams(params)
    sp.set('page', String(p))
    return `${basePath}?${sp.toString()}`
  }
  return (
    <nav className="mt-8 flex items-center justify-center gap-2" aria-label="Pagination">
      {page > 1 && <Link href={qs(page - 1)} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-800">← Prev</Link>}
      <span className="text-sm text-gray-500 dark:text-gray-400">Page {page} of {totalPages}</span>
      {page < totalPages && <Link href={qs(page + 1)} className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-100 dark:border-gray-700 dark:hover:bg-gray-800">Next →</Link>}
    </nav>
  )
}
