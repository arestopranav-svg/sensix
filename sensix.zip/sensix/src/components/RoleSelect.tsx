'use client'
import { useTransition } from 'react'
import { setUserRole } from '@/app/admin/actions'
export default function RoleSelect({ userId, current }: { userId: string; current: string }) {
  const [, start] = useTransition()
  return (
    <select defaultValue={current}
      onChange={(e) => start(async () => { await setUserRole(userId, e.target.value) })}
      className="rounded border border-gray-300 bg-transparent px-1.5 py-1 text-xs dark:border-gray-700">
      {['user', 'editor', 'moderator', 'admin', 'super_admin'].map((r) => <option key={r} value={r}>{r}</option>)}
    </select>
  )
}
