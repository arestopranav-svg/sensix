"use client"
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Search } from 'lucide-react'

export default function SearchBar({ large = false, initialQuery = '' }: { large?: boolean; initialQuery?: string }) {
  const [q, setQ] = useState(initialQuery)
  const router = useRouter()
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`)
  }
  return (
    <form onSubmit={submit} className="relative w-full">
      <Search className={`absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 ${large ? 'h-5 w-5' : 'h-4 w-4'}`} />
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search games, devices, settings…"
        aria-label="Search"
        className={`w-full rounded-xl border border-gray-300 bg-white pl-10 pr-4 text-gray-900 shadow-sm outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-200 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-100 dark:focus:ring-brand-900 ${
          large ? 'py-3.5 text-base' : 'py-2 text-sm'}`}
      />
    </form>
  )
}
