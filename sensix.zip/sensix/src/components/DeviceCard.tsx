import Link from 'next/link'
import { spec } from '@/lib/utils'

export default function DeviceCard({ device }: { device: any }) {
  return (
    <Link href={`/devices/${device.slug}`}
      className="group rounded-2xl border border-gray-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md dark:border-gray-800 dark:bg-gray-900 dark:hover:border-brand-700">
      <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{device.device_brands?.name}</p>
      <h3 className="mt-0.5 font-semibold text-gray-900 group-hover:text-brand-600 dark:text-gray-100">{device.model}</h3>
      <dl className="mt-3 space-y-1 text-sm text-gray-600 dark:text-gray-300">
        <div className="flex justify-between gap-2"><dt className="text-gray-400">OS</dt><dd>{spec(device.os)}</dd></div>
        <div className="flex justify-between gap-2"><dt className="text-gray-400">Chipset</dt><dd className="text-right">{spec(device.processor)}</dd></div>
        <div className="flex justify-between gap-2"><dt className="text-gray-400">RAM</dt><dd>{spec(device.ram_gb, ' GB')}</dd></div>
      </dl>
    </Link>
  )
}
