import Link from 'next/link'
import { Gamepad2 } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-gray-50 dark:border-gray-800 dark:bg-gray-900">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:grid-cols-2 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 font-bold text-brand-600">
            <Gamepad2 className="h-5 w-5" /> SensiX
          </div>
          <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
            Your Device. Your Game. Your Settings.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Explore</h4>
          <ul className="mt-2 space-y-1.5 text-sm text-gray-500 dark:text-gray-400">
            <li><Link href="/games" className="hover:text-brand-600">All games</Link></li>
            <li><Link href="/devices" className="hover:text-brand-600">All devices</Link></li>
            <li><Link href="/search" className="hover:text-brand-600">Search settings</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Account</h4>
          <ul className="mt-2 space-y-1.5 text-sm text-gray-500 dark:text-gray-400">
            <li><Link href="/dashboard" className="hover:text-brand-600">Dashboard</Link></li>
            <li><Link href="/dashboard/submit" className="hover:text-brand-600">Submit settings</Link></li>
            <li><Link href="/login" className="hover:text-brand-600">Log in</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold text-gray-900 dark:text-gray-100">Legal</h4>
          <ul className="mt-2 space-y-1.5 text-sm text-gray-500 dark:text-gray-400">
            <li><Link href="/disclaimer" className="hover:text-brand-600">Disclaimer</Link></li>
            <li><Link href="/privacy" className="hover:text-brand-600">Privacy</Link></li>
            <li><Link href="/terms" className="hover:text-brand-600">Terms</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-gray-200 py-4 text-center text-xs text-gray-400 dark:border-gray-800">
        SensiX is an independent community platform. Not affiliated with, endorsed by, or sponsored by any game publisher or device manufacturer. Device specifications are community-maintained and may contain errors.
      </div>
    </footer>
  )
}
