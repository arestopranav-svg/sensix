"use client"
import { useState } from 'react'
import { Heart } from 'lucide-react'

export default function FavouriteButton({ targetType, targetId, initial }: { targetType: string; targetId: string; initial: boolean }) {
  const [on, setOn] = useState(initial)
  const [busy, setBusy] = useState(false)
  const toggle = async () => {
    if (busy) return
    setBusy(true)
    const res = await fetch('/api/favourites', {
      method: on ? 'DELETE' : 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target_type: targetType, target_id: targetId }),
    })
    if (res.ok) setOn(!on)
    setBusy(false)
  }
  return (
    <button onClick={toggle} disabled={busy}
      className={`inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-semibold ${on ? 'border-rose-300 text-rose-600 bg-rose-50 dark:bg-rose-900/20' : 'border-gray-300 text-gray-600 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-300'}`}>
      <Heart className={`h-4 w-4 ${on ? 'fill-rose-500 text-rose-500' : ''}`} /> {on ? 'Favourited' : 'Favourite'}
    </button>
  )
}
