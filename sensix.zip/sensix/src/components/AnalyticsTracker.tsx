"use client"
import { useEffect } from 'react'
import { usePathname } from 'next/navigation'

/** Fire-and-forget page_view events; failures are silent by design. */
export default function AnalyticsTracker() {
  const pathname = usePathname()
  useEffect(() => {
    fetch('/api/analytics', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ event: 'page_view', path: pathname }),
      keepalive: true,
    }).catch(() => {})
  }, [pathname])
  return null
}
