import Link from 'next/link'
import { BadgeCheck, Star } from 'lucide-react'
import { formatDate } from '@/lib/utils'

export default function SettingsCard({ s }: { s: any }) {
  return (
    <Link href={`/settings/${s.id}`}
      className="group rounded-2xl border border-gray-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-brand-300 hover:shadow-md dark:border-gray-800 dark:bg-gray-900 dark:hover:border-brand-700">
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-semibold leading-snug text-gray-900 group-hover:text-brand-600 dark:text-gray-100">{s.title}</h3>
        {s.is_verified && (
          <span title="Verified by SensiX staff" className="inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
            <BadgeCheck className="h-3.5 w-3.5" /> Verified
          </span>
        )}
      </div>
      <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">
        {s.games?.name}{s.devices ? ` · ${s.devices.device_brands?.name} ${s.devices.model}` : ''}
      </p>
      <div className="mt-3 flex items-center justify-between text-xs text-gray-400">
        <span className="inline-flex items-center gap-1">
          <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
          {s.rating_count > 0 ? `${Number(s.avg_rating).toFixed(1)} (${s.rating_count})` : 'No ratings yet'}
        </span>
        <span>Updated {formatDate(s.updated_at)}</span>
      </div>
    </Link>
  )
}
