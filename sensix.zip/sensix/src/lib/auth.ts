import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import type { SupabaseClient, User } from '@supabase/supabase-js'

export type Role = 'user' | 'editor' | 'moderator' | 'admin' | 'super_admin'
const STAFF: Role[] = ['editor', 'moderator', 'admin', 'super_admin']
const ADMINS: Role[] = ['admin', 'super_admin']
const MODS: Role[] = ['moderator', 'admin', 'super_admin']

export async function getUserWithRole(supabase: SupabaseClient) {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return { user: null as User | null, role: null as Role | null, suspended: false }
  const { data: profile } = await supabase
    .from('profiles').select('role, suspended').eq('id', user.id).single()
  return {
    user,
    role: (profile?.role ?? 'user') as Role,
    suspended: profile?.suspended ?? false,
  }
}

/** Require a signed-in, non-suspended user. Returns user or redirects. */
export async function requireUser() {
  const supabase = createClient()
  const { user, suspended } = await getUserWithRole(supabase)
  if (!user || suspended) redirect('/login')
  return { supabase, user }
}

/** Require staff role. Server-side enforcement — never UI-only. */
export async function requireStaff(roles: Role[] = STAFF) {
  const { supabase, user, role, suspended } = await requireUserFull()
  if (!role || !roles.includes(role)) redirect('/')
  return { supabase, user, role }
}

export async function requireUserFull() {
  const supabase = createClient()
  const { user, role, suspended } = await getUserWithRole(supabase)
  if (!user || suspended) redirect('/login')
  return { supabase, user, role: role as Role, suspended }
}

/** Check a module permission for the caller's role (database-backed). */
export async function can(supabase: SupabaseClient, role: Role | null, module: string): Promise<boolean> {
  if (!role) return false
  if (role === 'super_admin') return true
  const { data } = await supabase
    .from('admin_permissions')
    .select('can_read, can_write')
    .eq('role', role).eq('module', module)
    .maybeSingle()
  return !!data?.can_write
}

export const isStaff = (r: Role | null) => !!r && STAFF.includes(r)
export const isAdmin = (r: Role | null) => !!r && ADMINS.includes(r)
export const isMod = (r: Role | null) => !!r && MODS.includes(r)
