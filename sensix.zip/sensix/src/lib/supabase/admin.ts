import { createClient as createSupabaseClient } from '@supabase/supabase-js'

/**
 * SERVICE-ROLE client. SERVER ONLY — never import from client components.
 * Bypasses RLS: use only for admin operations that RLS intentionally blocks
 * (bootstrap, analytics aggregation, user suspension).
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!url || !key) throw new Error('Missing Supabase server configuration')
  return createSupabaseClient(url, key, {
    auth: { autoRefreshToken: false, persistSession: false },
  })
}
