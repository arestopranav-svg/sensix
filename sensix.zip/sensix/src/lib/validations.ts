import { z } from 'zod'

export const settingsValuesSchema = z.record(
  z.string().max(60),
  z.union([z.string().max(200), z.number(), z.boolean(),
    z.record(z.string().max(30), z.union([z.number(), z.string(), z.boolean()]))])
)

export const settingsCategorySchema = z.enum([
  'sensitivity', 'graphics', 'controls', 'crosshair', 'keybindings', 'hud', 'other',
])

export const submissionSchema = z.object({
  game_id: z.string().uuid(),
  device_id: z.string().uuid().nullable().optional(),
  platform_id: z.string().uuid(),
  title: z.string().min(5).max(120),
  category: settingsCategorySchema,
  values: settingsValuesSchema,
  control_type: z.enum(['touch', 'mouse', 'controller']).nullable().optional(),
  gyroscope: z.boolean().nullable().optional(),
  game_version: z.string().max(40).nullable().optional(),
})

export const profileUpdateSchema = z.object({
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/, 'Letters, numbers, underscores only'),
  country_id: z.string().uuid().nullable().optional(),
  preferred_platform_id: z.string().uuid().nullable().optional(),
})

export const gameSchema = z.object({
  name: z.string().min(2).max(80),
  slug: z.string().min(2).max(80).regex(/^[a-z0-9-]+$/),
  publisher: z.string().max(80).nullable().optional(),
  category_id: z.string().uuid().nullable().optional(),
  description: z.string().max(2000).nullable().optional(),
})

export const deviceSchema = z.object({
  brand_id: z.string().uuid(),
  model: z.string().min(1).max(120),
  slug: z.string().min(2).max(160).regex(/^[a-z0-9-]+$/),
  category: z.enum(['phone', 'tablet', 'laptop', 'desktop', 'console', 'other']),
  os: z.string().max(60).nullable().optional(),
  processor: z.string().max(120).nullable().optional(),
  gpu: z.string().max(120).nullable().optional(),
  ram_gb: z.coerce.number().min(0).max(1024).nullable().optional(),
  storage_gb: z.coerce.number().min(0).max(8192).nullable().optional(),
  display: z.string().max(120).nullable().optional(),
  refresh_rate: z.coerce.number().int().min(1).max(1000).nullable().optional(),
  release_info: z.string().max(80).nullable().optional(),
  source_ref: z.string().url().max(500).nullable().optional(),
})

export const ratingSchema = z.object({ rating: z.number().int().min(1).max(5) })

export type SubmissionInput = z.infer<typeof submissionSchema>
