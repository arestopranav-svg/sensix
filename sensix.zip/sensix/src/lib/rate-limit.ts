/**
 * Lightweight rate limiter. Uses Upstash Redis when UPSTASH_REDIS_REST_URL is set,
 * otherwise an in-memory Map (per-instance; fine for single-server dev, and
 * Vercel serverless is short-lived so prefer Upstash in production).
 */
type Bucket = { count: number; resetAt: number }
const memory = new Map<string, Bucket>()

export async function rateLimit(
  key: string,
  limit: number,
  windowMs: number
): Promise<{ ok: boolean; remaining: number; resetAt: number }> {
  const now = Date.now()

  if (process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN) {
    try {
      const res = await fetch(
        `${process.env.UPSTASH_REDIS_REST_URL}/pipeline`,
        {
          method: 'POST',
          headers: { Authorization: `Bearer ${process.env.UPSTASH_REDIS_REST_TOKEN}` },
          body: JSON.stringify([
            ['INCR', `rl:${key}`],
            ['PEXPIRE', `rl:${key}`, windowMs, 'NX'],
            ['PTTL', `rl:${key}`],
          ]),
          cache: 'no-store',
        }
      )
      if (res.ok) {
        const [[, count], , [, ttl]] = await res.json()
        const ttlMs = ttl > 0 ? ttl : windowMs
        return { ok: Number(count) <= limit, remaining: Math.max(0, limit - Number(count)), resetAt: now + ttlMs }
      }
    } catch { /* fall through to memory */ }
  }

  const bucket = memory.get(key)
  if (!bucket || bucket.resetAt < now) {
    memory.set(key, { count: 1, resetAt: now + windowMs })
    return { ok: true, remaining: limit - 1, resetAt: now + windowMs }
  }
  bucket.count += 1
  return { ok: bucket.count <= limit, remaining: Math.max(0, limit - bucket.count), resetAt: bucket.resetAt }
}

/** Extract a best-effort client IP for rate-limit keys. */
export function clientIp(req: Request): string {
  const fwd = req.headers.get('x-forwarded-for')
  if (fwd) return fwd.split(',')[0].trim()
  return req.headers.get('x-real-ip') ?? 'unknown'
}
