export function cn(...classes: (string | false | null | undefined)[]) {
  return classes.filter(Boolean).join(' ')
}

export function formatDate(iso: string | null | undefined) {
  if (!iso) return '—'
  return new Date(iso).toLocaleDateString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric',
  })
}

/** Display helper: render "unknown" instead of blank for missing spec fields. */
export function spec(v: string | number | null | undefined, suffix = '') {
  return v === null || v === undefined || v === '' ? (
    <span className="text-gray-400 italic">unknown</span>
  ) : (
    <span>{String(v)}{suffix}</span>
  )
}

export function slugify(s: string) {
  return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
}
