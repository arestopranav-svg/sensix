export const metadata = { title: 'Privacy Policy' }
export default function Privacy() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-2xl font-bold">Privacy Policy</h1>
      <div className="mt-4 space-y-3 text-sm text-gray-600 dark:text-gray-300">
        <p>Account data (email, username, country, preferences) is stored to provide the service and deleted on account-deletion request.</p>
        <p>We store minimal analytics events (page views, searches) to improve the platform. No personal content is sold to third parties.</p>
        <p>Authentication is handled by Supabase using industry-standard secure sessions. Passwords and OTP codes are never stored by SensiX in plaintext.</p>
        <p>Contact the site operators to exercise data-access or deletion rights.</p>
      </div>
    </div>
  )
}
