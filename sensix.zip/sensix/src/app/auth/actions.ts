'use server'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

function nextPath(formData: FormData): string {
  const next = String(formData.get('next') ?? '/dashboard')
  return next.startsWith('/') && !next.startsWith('//') ? next : '/dashboard'
}

export async function signInWithEmail(formData: FormData) {
  const email = String(formData.get('email') ?? '')
  const password = String(formData.get('password') ?? '')
  if (!email.includes('@') || password.length < 6) redirect('/login?error=invalid')
  const supabase = createClient()
  const { error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) redirect('/login?error=credentials')
  redirect(nextPath(formData))
}

export async function signUpWithEmail(formData: FormData) {
  const email = String(formData.get('email') ?? '')
  const password = String(formData.get('password') ?? '')
  if (!email.includes('@') || password.length < 8) redirect('/signup?error=weak')
  const supabase = createClient()
  const { error } = await supabase.auth.signUp({
    email, password,
    options: { emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback` },
  })
  if (error) redirect('/signup?error=failed')
  redirect('/signup?message=check-email')
}

export async function signInWithGoogle(formData: FormData) {
  const supabase = createClient()
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: {
      redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback?next=${encodeURIComponent(String(formData.get('next') ?? '/dashboard'))}`,
    },
  })
  if (error || !data.url) redirect('/login?error=oauth')
  redirect(data.url)
}

export async function signInWithPhone(formData: FormData) {
  const phone = String(formData.get('phone') ?? '').replace(/[\s-]/g, '')
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) redirect('/login?error=phone')
  const supabase = createClient()
  const { error } = await supabase.auth.signInWithOtp({ phone })
  if (error) redirect('/login?error=otp')
  redirect(`/login/verify?phone=${encodeURIComponent(phone)}`)
}

export async function verifyPhoneOtp(formData: FormData) {
  const phone = String(formData.get('phone') ?? '')
  const token = String(formData.get('token') ?? '')
  const supabase = createClient()
  const { error } = await supabase.auth.verifyOtp({ phone, token, type: 'sms' })
  if (error) redirect(`/login/verify?phone=${encodeURIComponent(phone)}&error=code`)
  redirect(nextPath(formData))
}

export async function resetPassword(formData: FormData) {
  const email = String(formData.get('email') ?? '')
  if (!email.includes('@')) redirect('/login?error=invalid')
  const supabase = createClient()
  await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${process.env.NEXT_PUBLIC_SITE_URL}/auth/callback?next=/dashboard/account`,
  })
  redirect('/login?message=reset-sent')
}

export async function signOut() {
  const supabase = createClient()
  await supabase.auth.signOut()
  redirect('/')
}
