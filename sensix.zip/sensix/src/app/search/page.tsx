import { createClient } from '@/lib/supabase/server'
import SearchBar from '@/components/SearchBar'
import GameCard from '@/components/GameCard'
import DeviceCard from '@/components/DeviceCard'
import SettingsCard from '@/components/SettingsCard'
import EmptyState from '@/components/EmptyState'

export const metadata = { title: 'Search' }
export const revalidate = 60

export default async function SearchPage({ searchParams }: { searchParams: Record<string, string> }) {
  const q = (searchParams.q ?? '').trim()
  const supabase = createClient()
  const [games, devices, settings] = q ? await Promise.all([
    supabase.from('games').select('*, game_categories(name), game_platforms(platforms(id, name)), game_settings(count)').eq('is_active', true).ilike('name', `%${q}%`).limit(6),
    supabase.from('devices').select('*, device_brands(name)').eq('is_active', true).or(`model.ilike.%${q}%,device_brands.name.ilike.%${q}%`).limit(8),
    supabase.from('game_settings').select('*, games(name), devices(device_brands(name), model)').eq('is_published', true).ilike('title', `%${q}%`).limit(10),
  ]) : [{ data: [] }, { data: [] }, { data: [] }]

  const empty = q && !games.data?.length && !devices.data?.length && !settings.data?.length

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-bold">Search</h1>
      <div className="mt-6 max-w-xl"><SearchBar large initialQuery={q} /></div>
      {q && (
        <p className="mt-4 text-sm text-gray-500">Results for "{q}" — {games.data!.length + devices.data!.length + settings.data!.length} matches</p>
      )}
      {empty && <div className="mt-8"><EmptyState title="No results found" hint="Check spelling, try a shorter term, or browse games and devices directly." /></div>}
      {!!games.data?.length && (
        <section className="mt-10"><h2 className="mb-4 text-xl font-bold">Games</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{games.data.map((g) => <GameCard key={g.id} game={g} />)}</div></section>
      )}
      {!!settings.data?.length && (
        <section className="mt-10"><h2 className="mb-4 text-xl font-bold">Settings profiles</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{settings.data.map((s) => <SettingsCard key={s.id} s={s} />)}</div></section>
      )}
      {!!devices.data?.length && (
        <section className="mt-10"><h2 className="mb-4 text-xl font-bold">Devices</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{devices.data.map((d) => <DeviceCard key={d.id} device={d} />)}</div></section>
      )}
    </div>
  )
}
