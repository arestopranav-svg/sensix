import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Navbar from '@/components/Navbar'
import Footer from '@/components/Footer'
import AnalyticsTracker from '@/components/AnalyticsTracker'

const inter = Inter({ subsets: ['latin'], display: 'swap' })

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'),
  title: {
    default: 'SensiX — Your Device. Your Game. Your Settings.',
    template: '%s | SensiX',
  },
  description: 'Global gaming sensitivity and settings platform. Find tuned settings for your exact device and favorite games, or share your own.',
  openGraph: {
    siteName: 'SensiX',
    type: 'website',
    title: 'SensiX — Your Device. Your Game. Your Settings.',
    description: 'Global gaming sensitivity and settings platform.',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <div className="flex min-h-screen flex-col">
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
        </div>
        <AnalyticsTracker />
      </body>
    </html>
  )
}
