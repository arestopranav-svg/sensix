import { signUpWithEmail, signInWithGoogle } from '@/app/auth/actions'
import Link from 'next/link'
export const metadata = { title: 'Sign up' }
export default function SignupPage({ searchParams }: { searchParams: Record<string, string> }) {
  return (
    <div className="mx-auto max-w-sm px-4 py-16">
      <h1 className="text-2xl font-bold">Create your account</h1>
      {searchParams.error && <p className="mt-4 rounded-lg bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">Sign-up failed. Password must be 8+ characters and the email valid.</p>}
      {searchParams.message === 'check-email' && <p className="mt-4 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">Check your inbox to verify your email address.</p>}
      <form action={signUpWithEmail} className="mt-4 space-y-3">
        <input name="email" type="email" required placeholder="Email" autoComplete="email" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900" />
        <input name="password" type="password" required minLength={8} placeholder="Password (8+ characters)" autoComplete="new-password" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900" />
        <button className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">Sign up</button>
      </form>
      <div className="my-4 flex items-center gap-3 text-xs text-gray-400"><hr className="flex-1 border-gray-200 dark:border-gray-700" /> OR <hr className="flex-1 border-gray-200 dark:border-gray-700" /></div>
      <form action={signInWithGoogle}>
        <button className="w-full rounded-lg border border-gray-300 py-2.5 text-sm font-semibold hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">Continue with Google</button>
      </form>
      <p className="mt-4 text-center text-sm text-gray-500">Already have an account? <Link href="/login" className="text-brand-600 hover:underline">Log in</Link></p>
    </div>
  )
}
