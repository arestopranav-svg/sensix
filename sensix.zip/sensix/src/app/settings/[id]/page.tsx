import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import CopyButton from '@/components/CopyButton'
import RatingStars from '@/components/RatingStars'
import FavouriteButton from '@/components/FavouriteButton'
import SaveButton from '@/components/SaveButton'
import { BadgeCheck } from 'lucide-react'
import { formatDate } from '@/lib/utils'
import type { Metadata } from 'next'

export const revalidate = 120

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const supabase = createClient()
  const { data } = await supabase.from('game_settings').select('title').eq('id', params.id).single()
  return { title: data?.title ?? 'Settings profile' }
}

function ValueTable({ values }: { values: Record<string, any> }) {
  const entries = Object.entries(values ?? {})
  if (!entries.length) return <p className="text-sm text-gray-400">No values recorded.</p>
  return (
    <table className="w-full text-sm">
      <thead><tr className="border-b border-gray-200 text-left text-xs uppercase text-gray-400 dark:border-gray-700"><th className="py-2 pr-4">Setting</th><th className="py-2">Value</th></tr></thead>
      <tbody>
        {entries.map(([k, v]) => (
          <tr key={k} className="border-b border-gray-100 last:border-0 dark:border-gray-800">
            <td className="py-2 pr-4 font-medium capitalize text-gray-600 dark:text-gray-300">{k.replace(/_/g, ' ')}</td>
            <td className="py-2">{typeof v === 'object' ? <ValueTable values={v} /> : String(v)}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}

export default async function SettingsPage({ params }: { params: { id: string } }) {
  const supabase = createClient()
  const { data: s } = await supabase.from('game_settings')
    .select('*, games(name, slug), devices(model, slug, device_brands(name)), platforms(name), settings_versions(version, notes, created_at)')
    .eq('id', params.id).eq('is_published', true).single()
  if (!s) notFound()

  const { data: { user } } = await supabase.auth.getUser()
  let myRating = 0, favourited = false, saved = false
  if (user) {
    const [r, f, sv] = await Promise.all([
      supabase.from('settings_ratings').select('rating').eq('settings_id', s.id).eq('user_id', user.id).maybeSingle(),
      supabase.from('user_favourites').select('id').eq('user_id', user.id).eq('target_type', 'settings').eq('target_id', s.id).maybeSingle(),
      supabase.from('saved_settings').select('settings_id').eq('user_id', user.id).eq('settings_id', s.id).maybeSingle(),
    ])
    myRating = r.data?.rating ?? 0
    favourited = !!f.data; saved = !!sv.data
  }

  const shareUrl = `${process.env.NEXT_PUBLIC_SITE_URL}/settings/${s.id}`

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <div className="flex items-start justify-between gap-3">
        <h1 className="text-2xl font-bold leading-snug">{s.title}</h1>
        {s.is_verified && (
          <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300">
            <BadgeCheck className="h-4 w-4" /> Verified
          </span>
        )}
      </div>
      <p className="mt-2 text-sm text-gray-500">
        {s.games?.name} · {s.devices ? `${s.devices.device_brands?.name} ${s.devices.model}` : 'Any device'} · {s.platforms?.name}
        {s.game_version ? ` · v${s.game_version}` : ''}
      </p>
      <div className="mt-6 rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-gray-900">
        <ValueTable values={s.values} />
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <CopyButton text={JSON.stringify(s.values, null, 2)} />
        <CopyButton text={shareUrl} label="Share link" />
        {user && (
          <>
            <FavouriteButton targetType="settings" targetId={s.id} initial={favourited} />
            <SaveButton settingsId={s.id} initial={saved} />
            <RatingStars settingsId={s.id} initial={myRating} />
          </>
        )}
      </div>
      <p className="mt-4 rounded-lg bg-amber-50 p-3 text-xs text-amber-700 dark:bg-amber-900/30 dark:text-amber-300">
        Disclaimer: sensitivity is personal. This profile is not guaranteed to improve your performance.
      </p>
      <dl className="mt-6 grid grid-cols-2 gap-x-8 gap-y-2 text-sm text-gray-500 sm:grid-cols-3">
        <div><dt className="text-gray-400">Source</dt><dd className="font-medium">{s.source_name ?? 'Community'}</dd></div>
        <div><dt className="text-gray-400">Control</dt><dd className="font-medium capitalize">{s.control_type ?? '—'}</dd></div>
        <div><dt className="text-gray-400">Gyroscope</dt><dd className="font-medium">{s.gyroscope === null ? '—' : s.gyroscope ? 'Yes' : 'No'}</dd></div>
        <div><dt className="text-gray-400">Added</dt><dd className="font-medium">{formatDate(s.created_at)}</dd></div>
        <div><dt className="text-gray-400">Updated</dt><dd className="font-medium">{formatDate(s.updated_at)}</dd></div>
        <div><dt className="text-gray-400">Rating</dt><dd className="font-medium">{s.rating_count ? `${Number(s.avg_rating).toFixed(1)} / 5 (${s.rating_count})` : 'Not rated yet'}</dd></div>
      </dl>
      {s.settings_versions?.length > 0 && (
        <section className="mt-8">
          <h2 className="font-semibold">Version history</h2>
          <ul className="mt-3 space-y-2 text-sm text-gray-500">
            {s.settings_versions.map((v: any) => (
              <li key={v.version} className="rounded-lg border border-gray-100 p-3 dark:border-gray-800">
                <span className="font-semibold text-gray-700 dark:text-gray-200">v{v.version}</span> · {formatDate(v.created_at)}{v.notes ? ` — ${v.notes}` : ''}
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  )
}
