import { createClient } from '@/lib/supabase/server'
import type { MetadataRoute } from 'next'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000'
  const supabase = createClient()
  const [{ data: games }, { data: devices }, { data: settings }] = await Promise.all([
    supabase.from('games').select('slug, updated_at').eq('is_active', true),
    supabase.from('devices').select('slug, updated_at').eq('is_active', true),
    supabase.from('game_settings').select('id, updated_at').eq('is_published', true),
  ])
  return [
    { url: base, changeFrequency: 'daily', priority: 1 },
    { url: `${base}/games`, changeFrequency: 'daily', priority: 0.9 },
    { url: `${base}/devices`, changeFrequency: 'daily', priority: 0.9 },
    { url: `${base}/search`, priority: 0.5 },
    ...(games ?? []).map((g) => ({ url: `${base}/games/${g.slug}`, lastModified: g.updated_at, priority: 0.8 })),
    ...(devices ?? []).map((d) => ({ url: `${base}/devices/${d.slug}`, lastModified: d.updated_at, priority: 0.8 })),
    ...(settings ?? []).map((s) => ({ url: `${base}/settings/${s.id}`, lastModified: s.updated_at, priority: 0.7 })),
  ] as MetadataRoute.Sitemap
}
