import { resetPassword } from '@/app/auth/actions'
export const metadata = { title: 'Reset password' }
export default function ResetPage() {
  return (
    <div className="mx-auto max-w-sm px-4 py-16">
      <h1 className="text-2xl font-bold">Reset password</h1>
      <p className="mt-1 text-sm text-gray-500">We&apos;ll email you a secure reset link.</p>
      <form action={resetPassword} className="mt-4 space-y-3">
        <input name="email" type="email" required placeholder="Email" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900" />
        <button className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">Send reset link</button>
      </form>
    </div>
  )
}
