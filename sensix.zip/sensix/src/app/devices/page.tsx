import { createClient } from '@/lib/supabase/server'
import DeviceCard from '@/components/DeviceCard'
import Pagination from '@/components/Pagination'
import EmptyState from '@/components/EmptyState'
import SearchBar from '@/components/SearchBar'

export const metadata = { title: 'Devices' }
export const revalidate = 300

export default async function DevicesPage({ searchParams }: { searchParams: Record<string, string> }) {
  const supabase = createClient()
  const page = Math.max(1, Number(searchParams.page ?? 1))
  const per = 12
  let query = supabase.from('devices')
    .select('*, device_brands(name)', { count: 'exact' })
    .eq('is_active', true).order('device_brands(name)').order('model')
  if (searchParams.brand) query = query.eq('device_brands.slug', searchParams.brand)
  if (searchParams.category) query = query.eq('category', searchParams.category)
  if (searchParams.os) query = query.ilike('os', `%${searchParams.os}%`)
  if (searchParams.q) query = query.or(`model.ilike.%${searchParams.q}%,device_brands.name.ilike.%${searchParams.q}%`)
  const { data: devices, count } = await query.range((page - 1) * per, page * per - 1)
  const { data: brands } = await supabase.from('device_brands').select('*').order('name')

  const sp = (k: string, v?: string) => {
    const p = new URLSearchParams(searchParams); v ? p.set(k, v) : p.delete(k); p.delete('page')
    return `/devices?${p.toString()}`
  }
  const cats = ['phone', 'tablet', 'laptop', 'desktop', 'console']

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="text-3xl font-bold">Devices</h1>
      <p className="mt-1 text-sm text-gray-500">Specifications are community-maintained; unknown fields are shown as "unknown". This database does not contain every device in the world — it grows continuously.</p>
      <div className="mt-6 max-w-md"><SearchBar initialQuery={searchParams.q ?? ''} /></div>
      <div className="mt-4 flex flex-wrap gap-2">
        <a href="/devices" className="rounded-full border border-gray-200 px-3 py-1 text-sm text-gray-600 dark:border-gray-700 dark:text-gray-300">All brands</a>
        {brands?.map((b) => (
          <a key={b.id} href={sp('brand', b.slug)}
            className={`rounded-full border px-3 py-1 text-sm ${searchParams.brand === b.slug ? 'border-brand-500 text-brand-600' : 'border-gray-200 text-gray-600 dark:border-gray-700 dark:text-gray-300'}`}>{b.name}</a>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {cats.map((c) => (
          <a key={c} href={sp('category', c)}
            className={`rounded-full border px-3 py-1 text-sm capitalize ${searchParams.category === c ? 'border-brand-500 text-brand-600' : 'border-gray-200 text-gray-600 dark:border-gray-700 dark:text-gray-300'}`}>{c}s</a>
        ))}
      </div>
      {devices?.length ? (
        <>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {devices.map((d) => <DeviceCard key={d.id} device={d} />)}
          </div>
          <Pagination page={page} totalPages={Math.ceil((count ?? 0) / per)} basePath="/devices" params={searchParams} />
        </>
      ) : <div className="mt-8"><EmptyState title="No devices found" hint="Try another brand, model or filter." /></div>}
    </div>
  )
}
