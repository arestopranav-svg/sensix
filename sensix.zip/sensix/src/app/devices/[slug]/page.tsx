import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import Link from 'next/link'
import SettingsCard from '@/components/SettingsCard'
import { spec, formatDate } from '@/lib/utils'
import EmptyState from '@/components/EmptyState'

export const revalidate = 300

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const supabase = createClient()
  const { data } = await supabase.from('devices').select('model, device_brands(name)').eq('slug', params.slug).single()
  if (!data) return { title: 'Device not found' }
  return { title: `${data.device_brands.name} ${data.model}`, description: `Gaming settings and specifications for the ${data.device_brands.name} ${data.model}.` }
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex justify-between gap-4 border-b border-gray-100 py-2.5 last:border-0 dark:border-gray-800">
      <dt className="text-sm text-gray-400">{label}</dt><dd className="text-right text-sm font-medium">{children}</dd>
    </div>
  )
}

export default async function DevicePage({ params }: { params: { slug: string } }) {
  const supabase = createClient()
  const { data: device } = await supabase.from('devices')
    .select('*, device_brands(name, slug)').eq('slug', params.slug).single()
  if (!device) notFound()
  const { data: settings } = await supabase.from('game_settings')
    .select('*, games(name)').eq('device_id', device.id).eq('is_published', true)
  const { data: games } = await supabase.from('game_settings')
    .select('games(id, name, slug)').eq('device_id', device.id).eq('is_published', true)
  const uniqGames = Array.from(new Map((games ?? []).map((g: any) => [g.games.id, g.games])).values())

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <Link href={`/devices?brand=${device.device_brands.slug}`} className="text-xs font-semibold uppercase tracking-wide text-brand-600 hover:underline">
        {device.device_brands.name}
      </Link>
      <h1 className="mt-1 text-3xl font-bold">{device.model}</h1>
      <div className="mt-6 grid gap-8 md:grid-cols-2">
        <section className="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-gray-900">
          <h2 className="mb-2 font-semibold">Specifications</h2>
          <dl>
            <Row label="Brand">{device.device_brands.name}</Row>
            <Row label="Model">{device.model}</Row>
            <Row label="Category"><span className="capitalize">{device.category}</span></Row>
            <Row label="Operating system">{spec(device.os)}</Row>
            <Row label="Processor / chipset">{spec(device.processor)}</Row>
            <Row label="GPU">{spec(device.gpu)}</Row>
            <Row label="RAM">{spec(device.ram_gb, ' GB')}</Row>
            <Row label="Storage">{spec(device.storage_gb, ' GB')}</Row>
            <Row label="Display">{spec(device.display)}</Row>
            <Row label="Refresh rate">{spec(device.refresh_rate, ' Hz')}</Row>
            <Row label="Release">{spec(device.release_info)}</Row>
          </dl>
          {device.source_ref && <a href={device.source_ref} target="_blank" rel="noopener noreferrer" className="mt-3 inline-block text-xs text-brand-600 hover:underline">Manufacturer reference ↗</a>}
          <p className="mt-4 text-xs text-gray-400">Spec accuracy not guaranteed. Unknown fields are never invented.</p>
        </section>
        <section>
          <h2 className="font-semibold">Available settings ({settings?.length ?? 0})</h2>
          {settings?.length ? (
            <div className="mt-3 space-y-3">{settings.map((s) => <SettingsCard key={s.id} s={s} />)}</div>
          ) : <div className="mt-3"><EmptyState title="No settings for this device yet" /></div>}
          {uniqGames.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-semibold text-gray-500">Supported games</h3>
              <div className="mt-2 flex flex-wrap gap-2">
                {uniqGames.map((g: any) => (
                  <Link key={g.id} href={`/games/${g.slug}`} className="rounded-full bg-brand-50 px-3 py-1 text-sm text-brand-700 dark:bg-brand-900/40 dark:text-brand-300">{g.name}</Link>
                ))}
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  )
}
