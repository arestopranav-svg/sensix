import { createClient } from '@/lib/supabase/server'
import GameCard from '@/components/GameCard'
import Pagination from '@/components/Pagination'
import EmptyState from '@/components/EmptyState'
import SearchBar from '@/components/SearchBar'

export const metadata = { title: 'Games' }
export const revalidate = 300

export default async function GamesPage({ searchParams }: { searchParams: Record<string, string> }) {
  const supabase = createClient()
  const page = Math.max(1, Number(searchParams.page ?? 1))
  const per = 12
  let query = supabase.from('games')
    .select('*, game_categories(name), game_platforms(platforms(id, name)), game_settings(count)', { count: 'exact' })
    .eq('is_active', true).order('name')
  if (searchParams.platform) query = query.eq('game_platforms.platforms.slug', searchParams.platform)
  if (searchParams.category) query = query.eq('game_categories.slug', searchParams.category)
  if (searchParams.q) query = query.ilike('name', `%${searchParams.q}%`)
  const { data: games, count } = await query.range((page - 1) * per, page * per - 1)
  const { data: platforms } = await supabase.from('platforms').select('*').order('name')
  const { data: categories } = await supabase.from('game_categories').select('*').order('name')

  const sp = (k: string, v?: string) => {
    const p = new URLSearchParams(searchParams); v ? p.set(k, v) : p.delete(k); p.delete('page')
    return `/games?${p.toString()}`
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="text-3xl font-bold">Games</h1>
      <p className="mt-1 text-sm text-gray-500">Game names and publishers are informational only. SensiX is not affiliated with any publisher.</p>
      <div className="mt-6 max-w-md"><SearchBar initialQuery={searchParams.q ?? ''} /></div>
      <div className="mt-6 flex flex-wrap gap-2">
        <a href="/games" className="rounded-full border border-gray-200 px-3 py-1 text-sm text-gray-600 dark:border-gray-700 dark:text-gray-300">All platforms</a>
        {platforms?.map((p) => (
          <a key={p.id} href={sp('platform', p.slug)}
            className={`rounded-full border px-3 py-1 text-sm ${searchParams.platform === p.slug ? 'border-brand-500 text-brand-600' : 'border-gray-200 text-gray-600 dark:border-gray-700 dark:text-gray-300'}`}>{p.name}</a>
        ))}
        {categories?.map((c) => (
          <a key={c.id} href={sp('category', c.slug)}
            className={`rounded-full border px-3 py-1 text-sm ${searchParams.category === c.slug ? 'border-brand-500 text-brand-600' : 'border-gray-200 text-gray-600 dark:border-gray-700 dark:text-gray-300'}`}>{c.name}</a>
        ))}
      </div>
      {games?.length ? (
        <>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {games.map((g) => <GameCard key={g.id} game={g} />)}
          </div>
          <Pagination page={page} totalPages={Math.ceil((count ?? 0) / per)} basePath="/games" params={searchParams} />
        </>
      ) : <div className="mt-8"><EmptyState title="No games found" hint="Try a different search or filter." /></div>}
    </div>
  )
}
