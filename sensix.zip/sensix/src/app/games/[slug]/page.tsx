import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import SettingsCard from '@/components/SettingsCard'
import CopyButton from '@/components/CopyButton'
import EmptyState from '@/components/EmptyState'

export const revalidate = 300

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const supabase = createClient()
  const { data } = await supabase.from('games').select('name, description').eq('slug', params.slug).single()
  if (!data) return { title: 'Game not found' }
  return { title: `${data.name} settings`, description: data.description ?? `${data.name} sensitivity, graphics and control settings on SensiX.` }
}

export default async function GamePage({ params }: { params: { slug: string } }) {
  const supabase = createClient()
  const { data: game } = await supabase.from('games')
    .select('*, game_categories(name), game_platforms(platforms(id, name))').eq('slug', params.slug).single()
  if (!game) notFound()
  const { data: settings } = await supabase.from('game_settings')
    .select('*, devices(device_brands(name), model)').eq('game_id', game.id).eq('is_published', true).order('is_verified', { ascending: false })

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <p className="text-xs font-semibold uppercase tracking-wide text-brand-600">{game.game_categories?.name ?? 'Game'}</p>
      <h1 className="mt-1 text-3xl font-bold">{game.name}</h1>
      <p className="mt-2 text-gray-500 dark:text-gray-400">{game.description}</p>
      <div className="mt-3 flex flex-wrap gap-1.5">
        {game.game_platforms?.map((gp: any) => (
          <span key={gp.platforms.id} className="rounded-md bg-gray-100 px-2 py-0.5 text-xs text-gray-600 dark:bg-gray-800 dark:text-gray-300">{gp.platforms.name}</span>
        ))}
      </div>
      <div className="mt-8">
        <h2 className="text-xl font-bold">Settings profiles</h2>
        {settings?.length ? (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {settings.map((s) => <SettingsCard key={s.id} s={s} />)}
          </div>
        ) : <div className="mt-4"><EmptyState title="No published settings yet" hint="Be the first to submit settings for this game." /></div>}
      </div>
      <div className="mt-8"><CopyButton text={`${process.env.NEXT_PUBLIC_SITE_URL}/games/${game.slug}`} label="Copy page link" /></div>
    </div>
  )
}
