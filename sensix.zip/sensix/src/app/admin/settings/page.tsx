import { requireStaff, can } from '@/lib/auth'
import { toggleSettings } from '../settings-actions'
import { redirect } from 'next/navigation'
import Link from 'next/link'
export const metadata = { title: 'Settings · Admin' }
export const dynamic = 'force-dynamic'

export default async function AdminSettings({ searchParams }: { searchParams: Record<string, string> }) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'settings'))) redirect('/admin')
  let query = supabase.from('game_settings').select('*, games(name), devices(model)').order('updated_at', { ascending: false })
  if (searchParams.game) query = query.eq('games.slug', searchParams.game)
  const { data: rows } = await query.limit(100)
  return (
    <div>
      <h1 className="text-2xl font-bold">Settings profiles</h1>
      <table className="mt-6 w-full text-sm">
        <thead><tr className="border-b border-gray-200 text-left text-xs uppercase text-gray-400 dark:border-gray-700">
          <th className="py-2">Title</th><th>Game</th><th>Device</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {rows?.map((s) => (
            <tr key={s.id} className="border-b border-gray-100 last:border-0 dark:border-gray-800">
              <td className="py-2.5 font-medium"><Link href={`/settings/${s.id}`} className="hover:text-brand-600">{s.title}</Link></td>
              <td>{s.games?.name}</td><td>{s.devices?.model ?? 'Any'}</td>
              <td>
                <span className={`rounded-full px-2 py-0.5 text-xs ${s.is_published ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300' : 'bg-gray-100 text-gray-500 dark:bg-gray-800'}`}>{s.is_published ? 'Published' : 'Hidden'}</span>
                {s.is_verified && <span className="ml-1 rounded-full bg-blue-50 px-2 py-0.5 text-xs text-blue-700 dark:bg-blue-900/30 dark:text-blue-300">Verified</span>}
              </td>
              <td className="space-x-3 text-right">
                <form action={toggleSettings.bind(null, s.id, !s.is_published, s.is_verified)} className="inline">
                  <button className="text-xs font-semibold text-gray-600 hover:underline">{s.is_published ? 'Unpublish' : 'Publish'}</button>
                </form>
                <form action={toggleSettings.bind(null, s.id, s.is_published, !s.is_verified)} className="inline">
                  <button className="text-xs font-semibold text-blue-600 hover:underline">{s.is_verified ? 'Unverify' : 'Verify'}</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
