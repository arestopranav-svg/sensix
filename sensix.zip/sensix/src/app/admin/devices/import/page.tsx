'use client'
import { useState } from 'react'
export default function ImportPage() {
  const [result, setResult] = useState<string>('')
  const [busy, setBusy] = useState(false)
  const upload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setBusy(true); setResult('')
    const fd = new FormData(e.currentTarget)
    const res = await fetch('/api/admin/devices/import', { method: 'POST', body: fd })
    setResult(await res.text())
    setBusy(false)
  }
  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold">Import devices (CSV)</h1>
      <p className="mt-2 text-sm text-gray-500">Columns: brand_slug, model, slug, category, os, processor, gpu, ram_gb, storage_gb, display, refresh_rate, release_info, source_ref. Duplicates (same brand + model) are skipped.</p>
      <form onSubmit={upload} className="mt-6 space-y-3">
        <input type="file" name="file" accept=".csv" required className="block w-full text-sm" />
        <button disabled={busy} className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white disabled:opacity-50">{busy ? 'Importing…' : 'Import'}</button>
      </form>
      {result && <pre className="mt-4 overflow-x-auto rounded-lg bg-gray-50 p-4 text-xs dark:bg-gray-900">{result}</pre>}
    </div>
  )
}
