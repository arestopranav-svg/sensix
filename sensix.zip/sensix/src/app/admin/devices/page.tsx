import { requireStaff, can } from '@/lib/auth'
import { upsertDevice, deleteDevice } from '../actions'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import Pagination from '@/components/Pagination'
export const metadata = { title: 'Devices · Admin' }
export const dynamic = 'force-dynamic'

export default async function AdminDevices({ searchParams }: { searchParams: Record<string, string> }) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'devices'))) redirect('/admin')
  const page = Math.max(1, Number(searchParams.page ?? 1))
  const [{ data: devices, count }, { data: brands }] = await Promise.all([
    supabase.from('devices').select('*, device_brands(name)', { count: 'exact' }).order('model').range((page - 1) * 25, page * 25 - 1),
    supabase.from('device_brands').select('*').order('name'),
  ])
  const inp = 'rounded-lg border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900'
  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Devices</h1>
        <div className="flex gap-2 text-sm">
          <a href="/api/admin/devices/export" className="rounded-lg border border-gray-300 px-3 py-1.5 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">Export CSV</a>
          <a href="/admin/devices/import" className="rounded-lg border border-gray-300 px-3 py-1.5 hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">Import CSV</a>
        </div>
      </div>
      <details className="mt-6 rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
        <summary className="cursor-pointer text-sm font-semibold text-brand-600">+ Add device</summary>
        <form action={upsertDevice} className="mt-4 grid gap-2 sm:grid-cols-4">
          <select name="brand_id" required className={inp}>{brands?.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select>
          <input name="model" required placeholder="Exact model" className={inp} />
          <input name="slug" required placeholder="unique-slug" pattern="[a-z0-9-]+" className={inp} />
          <select name="category" required className={inp}>
            <option value="phone">Phone</option><option value="tablet">Tablet</option><option value="laptop">Laptop</option>
            <option value="desktop">Desktop</option><option value="console">Console</option><option value="other">Other</option>
          </select>
          {['os', 'processor', 'gpu', 'display', 'release_info', 'source_ref'].map((f) => (
            <input key={f} name={f} placeholder={f.replace('_', ' ')} className={inp} />
          ))}
          <input name="ram_gb" type="number" step="0.5" placeholder="RAM (GB)" className={inp} />
          <input name="storage_gb" type="number" step="1" placeholder="Storage (GB)" className={inp} />
          <input name="refresh_rate" type="number" placeholder="Refresh rate (Hz)" className={inp} />
          <button className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white sm:col-span-4">Save device</button>
        </form>
      </details>
      <table className="mt-6 w-full text-sm">
        <thead><tr className="border-b border-gray-200 text-left text-xs uppercase text-gray-400 dark:border-gray-700">
          <th className="py-2">Model</th><th>Brand</th><th>OS</th><th>Chipset</th><th></th></tr></thead>
        <tbody>
          {devices?.map((d) => (
            <tr key={d.id} className="border-b border-gray-100 last:border-0 dark:border-gray-800">
              <td className="py-2.5 font-medium"><Link href={`/devices/${d.slug}`} className="hover:text-brand-600">{d.model}</Link></td>
              <td>{d.device_brands?.name}</td><td>{d.os ?? '—'}</td><td>{d.processor ?? 'unknown'}</td>
              <td className="text-right">
                <form action={deleteDevice.bind(null, d.id)}>
                  <button className="text-xs font-semibold text-rose-600 hover:underline">Delete</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <Pagination page={page} totalPages={Math.ceil((count ?? 0) / 25)} basePath="/admin/devices" params={searchParams} />
    </div>
  )
}
