'use server'
import { requireStaff, can } from '@/lib/auth'
import { createAdminClient } from '@/lib/supabase/admin'
import { revalidatePath } from 'next/cache'
import { z } from 'zod'

const reviewSchema = z.enum(['approve', 'reject', 'request_changes'])

export async function reviewSubmission(submissionId: string, formData: FormData) {
  const { supabase, user, role } = await requireStaff()
  if (!(await can(supabase, role, 'submissions'))) throw new Error('Forbidden')
  const action = reviewSchema.parse(formData.get('action'))
  const notes = String(formData.get('notes') ?? '') || null
  const admin = createAdminClient()

  const { data: sub } = await admin.from('user_submissions').select('*').eq('id', submissionId).single()
  if (!sub) throw new Error('Not found')

  await admin.from('user_submissions').update({
    status: action === 'approve' ? 'approved' : action === 'reject' ? 'rejected' : 'needs_changes',
    admin_notes: notes, reviewed_by: user.id, reviewed_at: new Date().toISOString(),
  }).eq('id', submissionId)
  await admin.from('submission_reviews').insert({ submission_id: submissionId, reviewer_id: user.id, action, notes })

  if (action === 'approve') {
    const { data: created } = await admin.from('game_settings').insert({
      game_id: sub.game_id, device_id: sub.device_id, platform_id: sub.platform_id,
      title: sub.title, category: sub.category, values: sub.values,
      control_type: sub.control_type, gyroscope: sub.gyroscope, game_version: sub.game_version,
      author_id: sub.user_id, source_name: 'Community', is_verified: false, is_published: true,
    }).select('id').single()
    if (created) {
      await admin.from('settings_versions').insert({ settings_id: created.id, version: 1, values: sub.values, changed_by: user.id, notes: 'Initial version (approved submission)' })
    }
  }
  await admin.rpc('write_audit' as never, { p_action: `submission.${action}`, p_entity: 'user_submissions', p_entity_id: submissionId } as never)
  revalidatePath('/admin/submissions')
}

const gameInput = z.object({
  name: z.string().min(2).max(80), slug: z.string().min(2).max(80).regex(/^[a-z0-9-]+$/),
  publisher: z.string().max(80).nullable().optional(),
  category_id: z.string().uuid().nullable().optional(),
  description: z.string().max(2000).nullable().optional(),
})

export async function upsertGame(formData: FormData) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'games'))) throw new Error('Forbidden')
  const input = gameInput.parse({
    name: formData.get('name'), slug: formData.get('slug'), publisher: formData.get('publisher') || null,
    category_id: formData.get('category_id') || null, description: formData.get('description') || null,
  })
  const admin = createAdminClient()
  const id = formData.get('id') as string | null
  const q = id ? admin.from('games').update(input).eq('id', id) : admin.from('games').insert(input)
  const { error } = await q
  if (error) throw new Error(error.message)
  await admin.rpc('write_audit' as never, { p_action: id ? 'game.update' : 'game.create', p_entity: 'games', p_entity_id: id } as never)
  revalidatePath('/admin/games')
}

export async function deleteGame(id: string) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'games'))) throw new Error('Forbidden')
  const admin = createAdminClient()
  await admin.from('games').delete().eq('id', id)
  await admin.rpc('write_audit' as never, { p_action: 'game.delete', p_entity: 'games', p_entity_id: id } as never)
  revalidatePath('/admin/games')
}

export async function setUserRole(userId: string, roleName: string) {
  const { supabase, role } = await requireStaff(['admin', 'super_admin'])
  if (role !== 'super_admin' && roleName === 'super_admin') throw new Error('Only super admins can grant super admin')
  const admin = createAdminClient()
  await admin.from('profiles').update({ role: roleName }).eq('id', userId)
  await admin.rpc('write_audit' as never, { p_action: 'user.role_change', p_entity: 'profiles', p_entity_id: userId, p_metadata: { role: roleName } } as never)
  revalidatePath('/admin/users')
}

export async function setUserSuspended(userId: string, suspended: boolean) {
  const { supabase, role } = await requireStaff(['admin', 'super_admin'])
  if (!(await can(supabase, role, 'users'))) throw new Error('Forbidden')
  const admin = createAdminClient()
  await admin.from('profiles').update({ suspended }).eq('id', userId)
  await admin.rpc('write_audit' as never, { p_action: suspended ? 'user.suspend' : 'user.restore', p_entity: 'profiles', p_entity_id: userId } as never)
  revalidatePath('/admin/users')
}

export async function upsertDevice(formData: FormData) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'devices'))) throw new Error('Forbidden')
  const admin = createAdminClient()
  const nullable = (k: string) => { const v = formData.get(k); return v === '' || v === null ? null : v }
  const num = (k: string) => { const v = formData.get(k); return v === '' || v === null ? null : Number(v) }
  const input = {
    brand_id: formData.get('brand_id'), model: formData.get('model'), slug: formData.get('slug'),
    category: formData.get('category'), os: nullable('os'), processor: nullable('processor'), gpu: nullable('gpu'),
    ram_gb: num('ram_gb'), storage_gb: num('storage_gb'), display: nullable('display'),
    refresh_rate: num('refresh_rate') ? Math.trunc(num('refresh_rate')!) : null,
    release_info: nullable('release_info'), source_ref: nullable('source_ref'),
  }
  const id = formData.get('id') as string | null
  const q = id ? admin.from('devices').update(input).eq('id', id) : admin.from('devices').insert(input)
  const { error } = await q
  if (error) throw new Error(error.message) // unique(brand_id, model) surfaces here — duplicate prevention
  await admin.rpc('write_audit' as never, { p_action: id ? 'device.update' : 'device.create', p_entity: 'devices', p_entity_id: id } as never)
  revalidatePath('/admin/devices')
}

export async function deleteDevice(id: string) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'devices'))) throw new Error('Forbidden')
  const admin = createAdminClient()
  await admin.from('devices').delete().eq('id', id)
  await admin.rpc('write_audit' as never, { p_action: 'device.delete', p_entity: 'devices', p_entity_id: id } as never)
  revalidatePath('/admin/devices')
}
