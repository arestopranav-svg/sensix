import { requireStaff, can } from '@/lib/auth'
import Link from 'next/link'

const nav = [
  { href: '/admin', label: 'Overview', module: null },
  { href: '/admin/submissions', label: 'Submissions', module: 'submissions' },
  { href: '/admin/games', label: 'Games', module: 'games' },
  { href: '/admin/devices', label: 'Devices', module: 'devices' },
  { href: '/admin/settings', label: 'Settings', module: 'settings' },
  { href: '/admin/users', label: 'Users', module: 'users' },
  { href: '/admin/content', label: 'Content', module: 'content' },
  { href: '/admin/analytics', label: 'Analytics', module: 'analytics' },
]

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const { supabase, role } = await requireStaff()
  const allowed = []
  for (const item of nav) {
    if (!item.module) { allowed.push(item); continue }
    if (await can(supabase, role, item.module)) allowed.push(item)
  }
  return (
    <div className="mx-auto flex max-w-7xl flex-col gap-8 px-4 py-10 lg:flex-row">
      <aside className="w-full shrink-0 lg:w-56">
        <p className="mb-3 px-3 text-xs font-semibold uppercase tracking-wide text-gray-400">Admin · {role}</p>
        <nav className="flex gap-1 overflow-x-auto lg:flex-col">
          {allowed.map((n) => (
            <Link key={n.href} href={n.href}
              className="whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">{n.label}</Link>
          ))}
        </nav>
      </aside>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  )
}
