import { requireStaff, can } from '@/lib/auth'
import { setUserSuspended } from '../actions'
import RoleSelect from '@/components/RoleSelect'
import { formatDate } from '@/lib/utils'
import { redirect } from 'next/navigation'
export const metadata = { title: 'Users · Admin' }
export const dynamic = 'force-dynamic'

export default async function AdminUsers({ searchParams }: { searchParams: Record<string, string> }) {
  const { supabase, role } = await requireStaff(['admin', 'super_admin'])
  if (!(await can(supabase, role, 'users'))) redirect('/admin')
  let query = supabase.from('profiles').select('*, countries(name)').order('created_at', { ascending: false })
  if (searchParams.q) query = query.or(`username.ilike.%${searchParams.q}%,email.ilike.%${searchParams.q}%`)
  const { data: users } = await query.limit(50)
  return (
    <div>
      <h1 className="text-2xl font-bold">Users</h1>
      <form className="mt-4"><input name="q" defaultValue={searchParams.q ?? ''} placeholder="Search username or email"
        className="w-full max-w-sm rounded-lg border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900" /></form>
      <table className="mt-6 w-full text-sm">
        <thead><tr className="border-b border-gray-200 text-left text-xs uppercase text-gray-400 dark:border-gray-700">
          <th className="py-2">Username</th><th>Email</th><th>Country</th><th>Role</th><th>Joined</th><th></th></tr></thead>
        <tbody>
          {users?.map((u) => (
            <tr key={u.id} className={`border-b border-gray-100 last:border-0 dark:border-gray-800 ${u.suspended ? 'opacity-50' : ''}`}>
              <td className="py-2.5 font-medium">{u.username}</td>
              <td>{u.email}</td><td>{u.countries?.name ?? '—'}</td>
              <td><RoleSelect userId={u.id} current={u.role} /></td>
              <td className="text-xs text-gray-400">{formatDate(u.created_at)}</td>
              <td className="text-right">
                <form action={setUserSuspended.bind(null, u.id, !u.suspended)}>
                  <button className={`text-xs font-semibold hover:underline ${u.suspended ? 'text-emerald-600' : 'text-rose-600'}`}>{u.suspended ? 'Restore' : 'Suspend'}</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
