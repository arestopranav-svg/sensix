'use server'
import { requireStaff, can } from '@/lib/auth'
import { createAdminClient } from '@/lib/supabase/admin'
import { revalidatePath } from 'next/cache'

export async function toggleSettings(id: string, isPublished: boolean, isVerified: boolean) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'settings'))) throw new Error('Forbidden')
  const admin = createAdminClient()
  await admin.from('game_settings').update({ is_published: isPublished, is_verified: isVerified }).eq('id', id)
  await admin.rpc('write_audit' as never, {
    p_action: 'settings.toggle', p_entity: 'game_settings', p_entity_id: id,
    p_metadata: { is_published: isPublished, is_verified: isVerified },
  } as never)
  revalidatePath('/admin/settings')
}
