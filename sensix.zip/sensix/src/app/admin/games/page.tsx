import { requireStaff, can } from '@/lib/auth'
import { upsertGame, deleteGame } from '../actions'
import { redirect } from 'next/navigation'
export const metadata = { title: 'Games · Admin' }
export const dynamic = 'force-dynamic'
export default async function AdminGames() {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'games'))) redirect('/admin')
  const [{ data: games }, { data: categories }] = await Promise.all([
    supabase.from('games').select('*, game_categories(name)').order('name'),
    supabase.from('game_categories').select('*').order('name'),
  ])
  const inp = 'rounded-lg border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900'
  return (
    <div>
      <h1 className="text-2xl font-bold">Games</h1>
      <form action={upsertGame} className="mt-6 grid gap-2 rounded-2xl border border-gray-200 bg-white p-4 sm:grid-cols-5 dark:border-gray-800 dark:bg-gray-900">
        <input name="name" required placeholder="Name" className={inp} />
        <input name="slug" required placeholder="slug-kebab-case" pattern="[a-z0-9-]+" className={inp} />
        <input name="publisher" placeholder="Publisher" className={inp} />
        <select name="category_id" className={inp}>{categories?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
        <button className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-semibold text-white">Add game</button>
        <input name="description" placeholder="Description (optional)" className={`${inp} sm:col-span-5`} />
      </form>
      <table className="mt-6 w-full text-sm">
        <thead><tr className="border-b border-gray-200 text-left text-xs uppercase text-gray-400 dark:border-gray-700">
          <th className="py-2">Name</th><th>Slug</th><th>Category</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {games?.map((g) => (
            <tr key={g.id} className="border-b border-gray-100 last:border-0 dark:border-gray-800">
              <td className="py-2.5 font-medium">{g.name}</td>
              <td className="font-mono text-xs text-gray-400">{g.slug}</td>
              <td>{g.game_categories?.name ?? '—'}</td>
              <td>{g.is_active ? 'Active' : 'Inactive'}</td>
              <td className="text-right">
                <form action={deleteGame.bind(null, g.id)}>
                  <button className="text-xs font-semibold text-rose-600 hover:underline">Delete</button>
                </form>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
