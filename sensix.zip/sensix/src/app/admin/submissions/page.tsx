import { requireStaff, can } from '@/lib/auth'
import { reviewSubmission } from '../actions'
import { formatDate } from '@/lib/utils'
import { redirect } from 'next/navigation'
export const metadata = { title: 'Submissions · Admin' }
export const dynamic = 'force-dynamic'

export default async function AdminSubmissions({ searchParams }: { searchParams: Record<string, string> }) {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'submissions'))) redirect('/admin')
  const { data: subs } = await supabase.from('user_submissions')
    .select('*, profiles(username, email), games(name), devices(model)').order('created_at', { ascending: false })
    .eq('status', searchParams.status ?? 'pending')
  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">Submissions</h1>
        <div className="flex flex-wrap gap-2 text-sm">
          {['pending', 'approved', 'rejected', 'needs_changes'].map((s) => (
            <a key={s} href={`/admin/submissions?status=${s}`}
              className={`rounded-full border px-3 py-1 capitalize ${(searchParams.status ?? 'pending') === s ? 'border-brand-500 text-brand-600' : 'border-gray-200 text-gray-500 dark:border-gray-700'}`}>{s.replace('_', ' ')}</a>
          ))}
        </div>
      </div>
      {!subs?.length && <p className="mt-6 text-sm text-gray-400">Queue empty.</p>}
      <ul className="mt-4 space-y-4">
        {subs?.map((s) => (
          <li key={s.id} className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
            <p className="font-semibold">{s.title}</p>
            <p className="mt-1 text-xs text-gray-400">{s.games?.name} · {s.devices?.model ?? 'Any device'} · by {s.profiles?.username} · {formatDate(s.created_at)}</p>
            <details className="mt-3"><summary className="cursor-pointer text-sm text-brand-600">View values</summary>
              <pre className="mt-2 overflow-x-auto rounded-lg bg-gray-50 p-3 text-xs dark:bg-gray-800">{JSON.stringify(s.values, null, 2)}</pre></details>
            <form action={reviewSubmission.bind(null, s.id)} className="mt-4 flex flex-wrap items-center gap-2">
              <input name="notes" placeholder="Moderation note (optional)" className="min-w-40 flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-900" />
              <button name="action" value="approve" className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">Approve</button>
              <button name="action" value="request_changes" className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700">Request changes</button>
              <button name="action" value="reject" className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-700">Reject</button>
            </form>
          </li>
        ))}
      </ul>
    </div>
  )
}
