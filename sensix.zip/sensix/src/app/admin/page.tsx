import { requireStaff } from '@/lib/auth'
import { createAdminClient } from '@/lib/supabase/admin'
export const metadata = { title: 'Admin' }
export const dynamic = 'force-dynamic'

export default async function AdminHome() {
  await requireStaff()
  const admin = createAdminClient()
  const [users, games, devices, settings, subs, events, popularGames, popularDevices] = await Promise.all([
    admin.from('profiles').select('id', { count: 'exact', head: true }),
    admin.from('games').select('id', { count: 'exact', head: true }),
    admin.from('devices').select('id', { count: 'exact', head: true }),
    admin.from('game_settings').select('id', { count: 'exact', head: true }),
    admin.from('user_submissions').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    admin.from('analytics_events').select('id', { count: 'exact', head: true }).gte('created_at', new Date(Date.now() - 86400000).toISOString()),
    admin.from('analytics_events').select('entity_id').eq('event', 'game_view').gte('created_at', new Date(Date.now() - 604800000).toISOString()),
    admin.from('analytics_events').select('entity_id').eq('event', 'device_view').gte('created_at', new Date(Date.now() - 604800000).toISOString()),
  ])
  const countBy = (rows: any[] | null) => {
    const m = new Map<string, number>()
    rows?.forEach((r) => m.set(r.entity_id, (m.get(r.entity_id) ?? 0) + 1))
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)
  }
  const stats: [string, number][] = [
    ['Total users', users.count ?? 0], ['Total games', games.count ?? 0], ['Total devices', devices.count ?? 0],
    ['Settings profiles', settings.count ?? 0], ['Pending submissions', subs.count ?? 0], ['Views (24h)', events.count ?? 0],
  ]
  return (
    <div>
      <h1 className="text-2xl font-bold">Overview</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map(([label, value]) => (
          <div key={label} className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
            <p className="text-3xl font-bold text-brand-600">{value}</p>
            <p className="mt-1 text-sm text-gray-500">{label}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <Panel title="Popular games (7d)">{countBy(popularGames.data).map(([id, n]) => <Row key={id} label={id.slice(0, 8)} value={n} />)}</Panel>
        <Panel title="Popular devices (7d)">{countBy(popularDevices.data).map(([id, n]) => <Row key={id} label={id.slice(0, 8)} value={n} />)}</Panel>
      </div>
    </div>
  )
}
const Panel = ({ title, children }: any) => (
  <section className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
    <h2 className="mb-3 font-semibold">{title}</h2>{children}
  </section>
)
const Row = ({ label, value }: any) => (
  <div className="flex justify-between border-b border-gray-100 py-2 text-sm last:border-0 dark:border-gray-800">
    <span className="font-mono text-xs text-gray-500">{label}</span><span className="font-semibold">{value}</span>
  </div>
)
