import { verifyPhoneOtp } from '@/app/auth/actions'
export const metadata = { title: 'Verify phone' }
export default function VerifyPage({ searchParams }: { searchParams: Record<string, string> }) {
  const phone = searchParams.phone ?? ''
  return (
    <div className="mx-auto max-w-sm px-4 py-16">
      <h1 className="text-2xl font-bold">Enter your code</h1>
      <p className="mt-1 text-sm text-gray-500">Sent via SMS to {phone}</p>
      {searchParams.error && <p className="mt-4 rounded-lg bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">Invalid code. Try again.</p>}
      <form action={verifyPhoneOtp} className="mt-4 space-y-3">
        <input type="hidden" name="phone" value={phone} />
        <input name="token" inputMode="numeric" pattern="[0-9]*" required placeholder="6-digit code" aria-label="OTP code"
          className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-center text-lg tracking-[0.5em] dark:border-gray-700 dark:bg-gray-900" />
        <button className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">Verify</button>
      </form>
    </div>
  )
}
