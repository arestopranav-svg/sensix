import { signInWithEmail, signInWithGoogle, signInWithPhone } from '@/app/auth/actions'
import Link from 'next/link'

export const metadata = { title: 'Log in' }

function ErrorBox({ error, message }: { error?: string; message?: string }) {
  const map: Record<string, string> = {
    credentials: 'Invalid email or password.', invalid: 'Please check the form fields.',
    oauth: 'Google sign-in failed. Try again.', otp: 'Could not send code. Check the number.',
    phone: 'Enter a valid number with country code, e.g. +919876543210.',
  }
  if (message === 'reset-sent') return <p className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">Password reset email sent.</p>
  if (message === 'check-email') return <p className="rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">Check your email to confirm your account.</p>
  if (error && map[error]) return <p className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">{map[error]}</p>
  return null
}

export default function LoginPage({ searchParams }: { searchParams: Record<string, string> }) {
  return (
    <div className="mx-auto max-w-sm px-4 py-16">
      <h1 className="text-2xl font-bold">Log in to SensiX</h1>
      <div className="mt-4"><ErrorBox error={searchParams.error} message={searchParams.message} /></div>
      <form action={signInWithEmail} className="mt-4 space-y-3">
        <input type="hidden" name="next" value={searchParams.next ?? '/dashboard'} />
        <input name="email" type="email" required placeholder="Email" autoComplete="email"
          className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900" />
        <input name="password" type="password" required placeholder="Password" autoComplete="current-password"
          className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900" />
        <button className="w-full rounded-lg bg-brand-600 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">Log in</button>
      </form>
      <div className="my-4 flex items-center gap-3 text-xs text-gray-400"><hr className="flex-1 border-gray-200 dark:border-gray-700" /> OR <hr className="flex-1 border-gray-200 dark:border-gray-700" /></div>
      <form action={signInWithGoogle}>
        <input type="hidden" name="next" value={searchParams.next ?? '/dashboard'} />
        <button className="w-full rounded-lg border border-gray-300 py-2.5 text-sm font-semibold hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">Continue with Google</button>
      </form>
      <form action={signInWithPhone} className="mt-3 flex gap-2">
        <input name="phone" type="tel" required placeholder="+91 98765 43210" aria-label="Phone number with country code"
          className="flex-1 rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900" />
        <button className="rounded-lg border border-gray-300 px-4 text-sm font-semibold hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800">Send code</button>
      </form>
      <p className="mt-4 text-center text-sm text-gray-500">
        <Link href="/reset-password" className="text-brand-600 hover:underline">Forgot password?</Link> · <Link href="/signup" className="text-brand-600 hover:underline">Create account</Link>
      </p>
    </div>
  )
}
