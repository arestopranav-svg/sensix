import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'
import SearchBar from '@/components/SearchBar'
import GameCard from '@/components/GameCard'
import DeviceCard from '@/components/DeviceCard'
import SettingsCard from '@/components/SettingsCard'
import { ArrowRight, Megaphone, Smartphone, Monitor } from 'lucide-react'

export const revalidate = 300

export default async function HomePage() {
  const supabase = createClient()

  const [{ data: banners }, { data: popularGames }, { data: recentSettings },
         { data: popularDevices }, { data: brands }, { data: platforms },
         { data: announcements }] = await Promise.all([
    supabase.from('banners').select('*').eq('is_active', true).eq('position', 'home_hero').order('sort_order').limit(1),
    supabase.from('games').select('*, game_categories(name), game_platforms(platforms(id, name)), game_settings(count)').eq('is_active', true).order('views', { ascending: false }).limit(6),
    supabase.from('game_settings').select('*, games(name), devices(device_brands(name), model)').eq('is_published', true).order('created_at', { ascending: false }).limit(4),
    supabase.from('devices').select('*, device_brands(name)').eq('is_active', true).order('views', { ascending: false }).limit(4),
    supabase.from('device_brands').select('*').order('name').limit(24),
    supabase.from('platforms').select('*').order('name'),
    supabase.from('announcements').select('*').eq('is_active', true).order('created_at', { ascending: false }).limit(3),
  ])

  const banner = banners?.[0]

  return (
    <div>
      {/* Hero */}
      <section className="border-b border-gray-100 bg-gradient-to-b from-brand-50 to-white dark:from-brand-950/40 dark:to-gray-950 dark:border-gray-800">
        <div className="mx-auto max-w-4xl px-4 py-16 text-center md:py-24">
          {banner && (
            <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-white px-4 py-1.5 text-sm font-medium text-brand-700 shadow-sm dark:bg-gray-900 dark:text-brand-300">
              {banner.title} {banner.link_url && <Link href={banner.link_url} className="inline-flex items-center gap-1 font-semibold">Learn more <ArrowRight className="h-3.5 w-3.5" /></Link>}
            </p>
          )}
          <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 md:text-5xl dark:text-white">
            Your Device. Your Game.<br />
            <span className="text-brand-600">Your Settings.</span>
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-lg text-gray-500 dark:text-gray-400">
            Find sensitivity, graphics and control settings tuned for your exact device — verified by staff and shared by the community.
          </p>
          <div className="mx-auto mt-8 max-w-xl"><SearchBar large /></div>
          <p className="mt-3 text-xs text-gray-400">
            SensiX does not guarantee any profile will improve your performance — settings are personal.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-12 space-y-16">
        {/* Popular games */}
        <section>
          <SectionHeader title="Popular games" href="/games" />
          {popularGames?.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {popularGames.map((g) => <GameCard key={g.id} game={g} />)}
            </div>
          ) : <p className="text-sm text-gray-400">No games yet.</p>}
        </section>

        {/* Recently added settings */}
        <section>
          <SectionHeader title="Latest settings" href="/search" />
          {recentSettings?.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {recentSettings.map((s) => <SettingsCard key={s.id} s={s} />)}
            </div>
          ) : <p className="text-sm text-gray-400">No settings published yet.</p>}
        </section>

        {/* Popular devices */}
        <section>
          <SectionHeader title="Popular devices" href="/devices" />
          {popularDevices?.length ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {popularDevices.map((d) => <DeviceCard key={d.id} device={d} />)}
            </div>
          ) : <p className="text-sm text-gray-400">No devices yet.</p>}
        </section>

        {/* Browse by platform */}
        <section>
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Browse by platform</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {(platforms ?? []).filter((p) => ['mobile', 'pc'].includes(p.type)).map((p) => (
              <Link key={p.id} href={`/games?platform=${p.slug}`}
                className="flex items-center gap-3 rounded-2xl border border-gray-200 bg-white p-5 shadow-sm transition hover:border-brand-300 hover:shadow-md dark:border-gray-800 dark:bg-gray-900">
                {p.type === 'mobile' ? <Smartphone className="h-6 w-6 text-brand-500" /> : <Monitor className="h-6 w-6 text-brand-500" />}
                <div>
                  <p className="font-semibold text-gray-900 dark:text-gray-100">{p.name}</p>
                  <p className="text-xs capitalize text-gray-400">{p.type}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Browse by brand */}
        <section>
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">Browse by device brand</h2>
          <div className="mt-4 flex flex-wrap gap-2">
            {(brands ?? []).map((b) => (
              <Link key={b.id} href={`/devices?brand=${b.slug}`}
                className="rounded-full border border-gray-200 bg-white px-4 py-1.5 text-sm text-gray-600 shadow-sm transition hover:border-brand-400 hover:text-brand-600 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300">
                {b.name}
              </Link>
            ))}
          </div>
          <p className="mt-3 text-xs text-gray-400">Our database grows continuously — it does not yet contain every device in the world.</p>
        </section>

        {/* Announcements */}
        {announcements && announcements.length > 0 && (
          <section>
            <h2 className="flex items-center gap-2 text-xl font-bold text-gray-900 dark:text-gray-100">
              <Megaphone className="h-5 w-5 text-brand-500" /> Latest updates
            </h2>
            <div className="mt-4 space-y-3">
              {announcements.map((a) => (
                <div key={a.id} className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
                  <p className="font-semibold text-gray-900 dark:text-gray-100">{a.title}</p>
                  <p className="mt-1 text-sm text-gray-500 dark:text-gray-400">{a.body}</p>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}

function SectionHeader({ title, href }: { title: string; href: string }) {
  return (
    <div className="mb-4 flex items-center justify-between">
      <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">{title}</h2>
      <Link href={href} className="inline-flex items-center gap-1 text-sm font-semibold text-brand-600 hover:text-brand-700">
        View all <ArrowRight className="h-4 w-4" />
      </Link>
    </div>
  )
}
