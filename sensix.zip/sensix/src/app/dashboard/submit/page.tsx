import { submitSettings } from '../actions'
import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'

export const metadata = { title: 'Submit settings' }

const inp = 'w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900'
const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <label className="block"><span className="mb-1 block text-sm font-medium text-gray-700 dark:text-gray-200">{label}</span>{children}</label>
)

export default async function SubmitPage({ searchParams }: { searchParams: Record<string, string> }) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')
  const [{ data: games }, { data: devices }, { data: platforms }] = await Promise.all([
    supabase.from('games').select('id, name').eq('is_active', true).order('name'),
    supabase.from('devices').select('id, model, device_brands(name)').eq('is_active', true).order('model').limit(500),
    supabase.from('platforms').select('id, name').order('name'),
  ])
  return (
    <div>
      <h1 className="text-2xl font-bold">Submit settings</h1>
      <p className="mt-1 text-sm text-gray-500">Submissions are reviewed by staff before publishing. Community submissions are never auto-verified.</p>
      {searchParams.error && <p className="mt-3 rounded-lg bg-rose-50 p-3 text-sm text-rose-700 dark:bg-rose-900/30 dark:text-rose-300">Submission failed — check all fields (values must be valid JSON).</p>}
      <form action={submitSettings} className="mt-6 max-w-xl space-y-4">
        <Field label="Title"><input name="title" required minLength={5} maxLength={120} placeholder="e.g. Galaxy S23 Ultra — FF headshot sensitivity" className={inp} /></Field>
        <Field label="Game">
          <select name="game_id" required className={inp}>{games?.map((g) => <option key={g.id} value={g.id}>{g.name}</option>)}</select>
        </Field>
        <Field label="Platform">
          <select name="platform_id" required className={inp}>{platforms?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        </Field>
        <Field label="Device (optional)">
          <select name="device_id" className={inp}><option value="">Any device</option>{devices?.map((d: any) => <option key={d.id} value={d.id}>{d.device_brands?.name} {d.model}</option>)}</select>
        </Field>
        <Field label="Category">
          <select name="category" className={inp}>
            <option value="sensitivity">Sensitivity</option><option value="graphics">Graphics</option>
            <option value="controls">Controls</option><option value="crosshair">Crosshair</option>
            <option value="keybindings">Key bindings</option><option value="hud">HUD</option><option value="other">Other</option>
          </select>
        </Field>
        <Field label="Control type">
          <select name="control_type" className={inp}><option value="">—</option><option value="touch">Touch</option><option value="mouse">Mouse</option><option value="controller">Controller</option></select>
        </Field>
        <Field label="Gyroscope"><select name="gyroscope" className={inp}><option value="">Not applicable</option><option value="true">On</option><option value="false">Off</option></select></Field>
        <Field label="Game version"><input name="game_version" maxLength={40} placeholder="e.g. OB48 / 3.4" className={inp} /></Field>
        <Field label="Settings values (JSON)">
          <textarea name="values" required rows={6} placeholder='{"general": 100, "red_dot": 95}' className={`${inp} font-mono text-xs`} />
          <p className="mt-1 text-xs text-gray-400">JSON object. Keys are game-specific — use the same structure the game uses.</p>
        </Field>
        <button className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">Submit for review</button>
      </form>
    </div>
  )
}
