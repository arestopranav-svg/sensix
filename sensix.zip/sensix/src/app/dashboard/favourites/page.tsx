import { requireUser } from '@/lib/auth'
import SettingsCard from '@/components/SettingsCard'
export const metadata = { title: 'Favourites' }
export default async function FavouritesPage() {
  const { supabase, user } = await requireUser()
  const [{ data: favSettings }, { data: favGames }, { data: favDevices }] = await Promise.all([
    supabase.from('user_favourites').select('target_id').eq('user_id', user.id).eq('target_type', 'settings'),
    supabase.from('user_favourites').select('target_id').eq('user_id', user.id).eq('target_type', 'game'),
    supabase.from('user_favourites').select('target_id').eq('user_id', user.id).eq('target_type', 'device'),
  ])
  const ids = (favSettings ?? []).map((f) => f.target_id)
  const gids = (favGames ?? []).map((f) => f.target_id)
  const dids = (favDevices ?? []).map((f) => f.target_id)
  const [{ data: settings }, { data: games }, { data: devices }] = await Promise.all([
    ids.length ? supabase.from('game_settings').select('*, games(name), devices(device_brands(name), model)').in('id', ids) : { data: [] },
    gids.length ? supabase.from('games').select('*, game_categories(name), game_platforms(platforms(id, name)), game_settings(count)').in('id', gids) : { data: [] },
    dids.length ? supabase.from('devices').select('*, device_brands(name)').in('id', dids) : { data: [] },
  ])
  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">Favourites & saved</h1>
      <section><h2 className="mb-3 font-semibold">Settings profiles</h2>
        {settings?.length ? <div className="grid gap-3 sm:grid-cols-2">{settings.map((s: any) => <SettingsCard key={s.id} s={s} />)}</div> : <p className="text-sm text-gray-400">None yet.</p>}</section>
      <section><h2 className="mb-3 font-semibold">Games</h2>
        {games?.length ? <ul className="text-sm">{games.map((g: any) => <li key={g.id}>• {g.name}</li>)}</ul> : <p className="text-sm text-gray-400">None yet.</p>}</section>
      <section><h2 className="mb-3 font-semibold">Devices</h2>
        {devices?.length ? <ul className="text-sm">{devices.map((d: any) => <li key={d.id}>• {d.device_brands?.name} {d.model}</li>)}</ul> : <p className="text-sm text-gray-400">None yet.</p>}</section>
    </div>
  )
}
