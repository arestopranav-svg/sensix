import { requireUser } from '@/lib/auth'
import { formatDate } from '@/lib/utils'
export const metadata = { title: 'My submissions' }
const statusStyle: Record<string, string> = {
  pending: 'bg-amber-50 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300',
  approved: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
  rejected: 'bg-rose-50 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300',
  needs_changes: 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300',
}
export default async function SubmissionsPage({ searchParams }: { searchParams: Record<string, string> }) {
  const { supabase, user } = await requireUser()
  const { data: subs } = await supabase.from('user_submissions')
    .select('*, games(name)').eq('user_id', user.id).order('created_at', { ascending: false })
  return (
    <div>
      <h1 className="text-2xl font-bold">My submissions</h1>
      {searchParams.message === 'submitted' && <p className="mt-3 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300">Submitted! Our team will review it.</p>}
      {!subs?.length ? <p className="mt-4 text-sm text-gray-400">No submissions yet.</p> : (
        <ul className="mt-4 space-y-3">
          {subs.map((s) => (
            <li key={s.id} className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
              <div className="flex items-center justify-between gap-3">
                <p className="font-medium">{s.title}</p>
                <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${statusStyle[s.status]}`}>{s.status.replace('_', ' ')}</span>
              </div>
              <p className="mt-1 text-xs text-gray-400">{s.games?.name} · {formatDate(s.created_at)}</p>
              {s.admin_notes && <p className="mt-2 rounded-lg bg-gray-50 p-2 text-sm text-gray-600 dark:bg-gray-800 dark:text-gray-300">Moderator note: {s.admin_notes}</p>}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
