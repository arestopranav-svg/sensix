import { requireUser } from '@/lib/auth'
import { updateProfile, requestAccountDeletion } from '../actions'
import { createClient } from '@/lib/supabase/server'
export const metadata = { title: 'Account settings' }
export default async function AccountPage() {
  const { supabase, user } = await requireUser()
  const [{ data: profile }, { data: countries }, { data: platforms }] = await Promise.all([
    supabase.from('profiles').select('*, countries(id, name)').eq('id', user.id).single(),
    supabase.from('countries').select('id, name').order('name'),
    supabase.from('platforms').select('id, name').order('name'),
  ])
  const inp = 'w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm dark:border-gray-700 dark:bg-gray-900'
  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-bold">Account settings</h1>
      <form action={updateProfile} className="mt-6 space-y-4">
        <label className="block"><span className="mb-1 block text-sm font-medium">Username</span>
          <input name="username" defaultValue={profile?.username ?? ''} required minLength={3} maxLength={30} pattern="[a-zA-Z0-9_]+" className={inp} /></label>
        <label className="block"><span className="mb-1 block text-sm font-medium">Email</span>
          <input value={profile?.email ?? ''} disabled className={`${inp} opacity-60`} /></label>
        <label className="block"><span className="mb-1 block text-sm font-medium">Country</span>
          <select name="country_id" defaultValue={profile?.countries?.id ?? ''} className={inp}>
            <option value="">—</option>{countries?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select></label>
        <label className="block"><span className="mb-1 block text-sm font-medium">Preferred platform</span>
          <select name="preferred_platform_id" defaultValue={profile?.preferred_platform_id ?? ''} className={inp}>
            <option value="">—</option>{platforms?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select></label>
        <button className="rounded-lg bg-brand-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-brand-700">Save changes</button>
      </form>
      <div className="mt-10 rounded-2xl border border-rose-200 p-5 dark:border-rose-900/50">
        <h2 className="font-semibold text-rose-700 dark:text-rose-300">Delete account</h2>
        <p className="mt-1 text-sm text-gray-500">Requests account deletion. Your data is removed after review.</p>
        <form action={requestAccountDeletion} className="mt-3">
          <button className="rounded-lg border border-rose-300 px-4 py-2 text-sm font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20">Request deletion</button>
        </form>
      </div>
    </div>
  )
}
