import { requireUser } from '@/lib/auth'
import Link from 'next/link'

const nav = [
  { href: '/dashboard', label: 'Overview' },
  { href: '/dashboard/submissions', label: 'My submissions' },
  { href: '/dashboard/submit', label: 'Submit settings' },
  { href: '/dashboard/favourites', label: 'Favourites & saved' },
  { href: '/dashboard/account', label: 'Account' },
]

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  await requireUser()
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-10 md:flex-row">
      <aside className="w-full shrink-0 md:w-52">
        <nav className="flex gap-1 overflow-x-auto md:flex-col">
          {nav.map((n) => (
            <Link key={n.href} href={n.href}
              className="whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800">{n.label}</Link>
          ))}
        </nav>
      </aside>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  )
}
