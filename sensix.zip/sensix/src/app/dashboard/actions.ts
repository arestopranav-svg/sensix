'use server'
import { requireUser } from '@/lib/auth'
import { submissionSchema } from '@/lib/validations'
import { redirect } from 'next/navigation'
import { revalidatePath } from 'next/cache'

export async function submitSettings(formData: FormData) {
  const { supabase, user } = await requireUser()
  let values: unknown
  try { values = JSON.parse(String(formData.get('values') ?? '{}')) }
  catch { redirect('/dashboard/submit?error=json') }

  const parsed = submissionSchema.safeParse({
    game_id: formData.get('game_id'),
    device_id: formData.get('device_id') || null,
    platform_id: formData.get('platform_id'),
    title: formData.get('title'),
    category: formData.get('category'),
    values,
    control_type: formData.get('control_type') || null,
    gyroscope: formData.get('gyroscope') === '' ? null : formData.get('gyroscope') === 'true',
    game_version: formData.get('game_version') || null,
  })
  if (!parsed.success) redirect('/dashboard/submit?error=validation')
  const { error } = await supabase.from('user_submissions').insert({ ...parsed.data, user_id: user.id })
  if (error) redirect('/dashboard/submit?error=failed')
  revalidatePath('/dashboard/submissions')
  redirect('/dashboard/submissions?message=submitted')
}

export async function updateProfile(formData: FormData) {
  const { supabase, user } = await requireUser()
  await supabase.from('profiles').update({
    username: String(formData.get('username') ?? ''),
    country_id: formData.get('country_id') || null,
    preferred_platform_id: formData.get('preferred_platform_id') || null,
  }).eq('id', user.id)
  revalidatePath('/dashboard/account')
}

export async function requestAccountDeletion() {
  const { supabase, user } = await requireUser()
  await supabase.from('profiles').update({ suspended: true }).eq('id', user.id)
  await supabase.auth.signOut()
  redirect('/?message=deletion-requested')
}
