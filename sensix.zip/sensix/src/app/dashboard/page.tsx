import { requireUserFull } from '@/lib/auth'
import SettingsCard from '@/components/SettingsCard'
import Link from 'next/link'
import { formatDate } from '@/lib/utils'

export const metadata = { title: 'Dashboard' }

export default async function DashboardPage() {
  const { supabase, user } = await requireUserFull()
  const { data: profile } = await supabase.from('profiles')
    .select('*, countries(name), platforms(name)').eq('id', user.id).single()
  const [{ data: submissions }, { data: saved }] = await Promise.all([
    supabase.from('user_submissions').select('id, title, status, created_at').eq('user_id', user.id).order('created_at', { ascending: false }).limit(5),
    supabase.from('saved_settings').select('*, game_settings(title, id, games(name))').eq('user_id', user.id).limit(4),
  ])
  return (
    <div>
      <h1 className="text-2xl font-bold">Welcome, {profile?.username}</h1>
      <p className="mt-1 text-sm text-gray-500">{profile?.email} · {profile?.countries?.name ?? 'Country not set'} · {profile?.platforms?.name ?? 'No preferred platform'}</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        <Stat label="Submissions" value={submissions?.length ?? 0} />
        <Stat label="Saved profiles" value={saved?.length ?? 0} />
        <Stat label="Pending review" value={submissions?.filter((s) => s.status === 'pending').length ?? 0} />
      </div>
      <Section title="My submissions" href="/dashboard/submissions">
        {submissions?.length ? (
          <ul className="divide-y divide-gray-100 rounded-2xl border border-gray-200 bg-white dark:divide-gray-800 dark:border-gray-800 dark:bg-gray-900">
            {submissions.map((s) => (
              <li key={s.id} className="flex items-center justify-between p-4 text-sm">
                <span className="font-medium">{s.title}</span>
                <span className="text-xs capitalize text-gray-400">{s.status} · {formatDate(s.created_at)}</span>
              </li>
            ))}
          </ul>
        ) : <p className="text-sm text-gray-400">Nothing submitted yet. <Link href="/dashboard/submit" className="text-brand-600 hover:underline">Submit your first settings</Link>.</p>}
      </Section>
      <Section title="Saved settings">
        <div className="grid gap-3 sm:grid-cols-2">
          {saved?.map((s: any) => <SettingsCard key={s.settings_id} s={{ ...s.game_settings }} />)}
        </div>
        {!saved?.length && <p className="text-sm text-gray-400">Profiles you save appear here.</p>}
      </Section>
    </div>
  )
}
const Stat = ({ label, value }: { label: string; value: number }) => (
  <div className="rounded-2xl border border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-gray-900">
    <p className="text-2xl font-bold text-brand-600">{value}</p>
    <p className="text-xs text-gray-500">{label}</p>
  </div>
)
const Section = ({ title, href, children }: { title: string; href?: string; children: React.ReactNode }) => (
  <section className="mt-8">
    <div className="mb-3 flex items-center justify-between">
      <h2 className="font-semibold">{title}</h2>
      {href && <Link href={href} className="text-sm text-brand-600 hover:underline">View all</Link>}
    </div>
    {children}
  </section>
)
