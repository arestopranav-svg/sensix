export const metadata = { title: 'Disclaimer' }
export default function Disclaimer() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-2xl font-bold">Disclaimer</h1>
      <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-gray-600 dark:text-gray-300">
        <li>SensiX is an independent platform and is <strong>not affiliated with, endorsed by, or sponsored by any game publisher or device manufacturer</strong>.</li>
        <li>Sensitivity and settings profiles are shared for reference. <strong>No profile is guaranteed to improve your performance</strong> — settings are personal and depend on play style, hardware and preference.</li>
        <li>Device specifications are community-maintained and may be inaccurate or incomplete; unknown fields are never invented.</li>
        <li>&quot;Verified&quot; means reviewed by SensiX staff for plausibility and completeness — it is not an endorsement by any publisher.</li>
      </ul>
    </div>
  )
}
