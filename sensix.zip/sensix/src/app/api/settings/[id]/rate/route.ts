import { requireUser } from '@/lib/auth'
import { createAdminClient } from '@/lib/supabase/admin'
import { ratingSchema } from '@/lib/validations'
import { rateLimit, clientIp } from '@/lib/rate-limit'
import { NextResponse } from 'next/server'

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const rl = await rateLimit(`rate:${clientIp(req)}`, 30, 60_000)
  if (!rl.ok) return NextResponse.json({ error: 'rate_limited' }, { status: 429 })
  const { user } = await requireUser()
  const parsed = ratingSchema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) return NextResponse.json({ error: 'invalid' }, { status: 400 })
  const admin = createAdminClient()
  await admin.from('settings_ratings').upsert({
    user_id: user.id, settings_id: params.id, rating: parsed.data.rating,
  })
  const { data: agg } = await admin.from('settings_ratings')
    .select('rating').eq('settings_id', params.id)
  const ratings = agg ?? []
  await admin.from('game_settings').update({
    avg_rating: ratings.reduce((a, r) => a + r.rating, 0) / ratings.length,
    rating_count: ratings.length,
  }).eq('id', params.id)
  return NextResponse.json({ ok: true })
}
