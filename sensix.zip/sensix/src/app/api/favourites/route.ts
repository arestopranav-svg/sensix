import { requireUser } from '@/lib/auth'
import { z } from 'zod'
import { NextResponse } from 'next/server'

const schema = z.object({
  target_type: z.enum(['game', 'device', 'settings']),
  target_id: z.string().uuid(),
})

async function handle(req: Request, method: 'POST' | 'DELETE') {
  const { supabase, user } = await requireUser()
  const parsed = schema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) return NextResponse.json({ error: 'invalid' }, { status: 400 })
  const row = { user_id: user.id, ...parsed.data }
  const q = method === 'POST'
    ? supabase.from('user_favourites').insert(row)
    : supabase.from('user_favourites').delete().match(row)
  const { error } = await q
  return NextResponse.json({ ok: !error }, { status: error ? 500 : 200 })
}
export async function POST(req: Request) { return handle(req, 'POST') }
export async function DELETE(req: Request) { return handle(req, 'DELETE') }
