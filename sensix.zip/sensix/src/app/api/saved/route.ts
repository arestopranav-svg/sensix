import { requireUser } from '@/lib/auth'
import { z } from 'zod'
import { NextResponse } from 'next/server'
const schema = z.object({ settings_id: z.string().uuid() })

async function handle(req: Request, method: 'POST' | 'DELETE') {
  const { supabase, user } = await requireUser()
  const parsed = schema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) return NextResponse.json({ error: 'invalid' }, { status: 400 })
  const row = { user_id: user.id, settings_id: parsed.data.settings_id }
  const q = method === 'POST'
    ? supabase.from('saved_settings').insert(row)
    : supabase.from('saved_settings').delete().match(row)
  const { error } = await q
  return NextResponse.json({ ok: !error }, { status: error ? 500 : 200 })
}
export async function POST(req: Request) { return handle(req, 'POST') }
export async function DELETE(req: Request) { return handle(req, 'DELETE') }
