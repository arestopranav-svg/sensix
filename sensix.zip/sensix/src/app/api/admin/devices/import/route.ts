import { requireStaff, can } from '@/lib/auth'
import { createAdminClient } from '@/lib/supabase/admin'
import { slugify } from '@/lib/utils'
import { NextResponse } from 'next/server'

export async function POST(req: Request) {
  const { supabase, user, role } = await requireStaff()
  if (!(await can(supabase, role, 'devices'))) return NextResponse.json('Forbidden', { status: 403 })
  const form = await req.formData()
  const file = form.get('file')
  if (!(file instanceof File)) return NextResponse.json('No file', { status: 400 })
  const text = await file.text()
  const lines = text.split(/\r?\n/).filter(Boolean)
  const header = lines[0].toLowerCase().split(',').map((h) => h.trim())
  const admin = createAdminClient()
  const { data: brands } = await admin.from('device_brands').select('id, slug')
  const brandMap = new Map((brands ?? []).map((b: any) => [b.slug, b.id]))

  let inserted = 0, failed = 0
  const errors: string[] = []
  const batch: any[] = []
  for (const line of lines.slice(1)) {
    const cols = line.split(',').map((c) => c.trim().replace(/^"|"$/g, ''))
    const row = Object.fromEntries(header.map((h, i) => [h, cols[i] ?? '']))
    const brandId = brandMap.get(row.brand_slug)
    if (!brandId || !row.model) { failed++; errors.push(`Bad row: ${line.slice(0, 60)}`); continue }
    batch.push({
      brand_id: brandId, model: row.model,
      slug: row.slug || slugify(`${row.brand_slug}-${row.model}`),
      category: ['phone', 'tablet', 'laptop', 'desktop', 'console', 'other'].includes(row.category) ? row.category : 'other',
      os: row.os || null, processor: row.processor || null, gpu: row.gpu || null,
      ram_gb: row.ram_gb ? Number(row.ram_gb) : null, storage_gb: row.storage_gb ? Number(row.storage_gb) : null,
      display: row.display || null, refresh_rate: row.refresh_rate ? Number(row.refresh_rate) : null,
      release_info: row.release_info || null, source_ref: row.source_ref || null,
    })
  }
  const { data, error } = await admin.from('devices')
    .upsert(batch, { onConflict: 'brand_id,model', ignoreDuplicates: false })
    .select('id')
  if (error) { failed += batch.length; errors.push(error.message) }
  else inserted = data?.length ?? 0
  await admin.rpc('write_audit' as never, {
    p_action: 'devices.import', p_entity: 'devices',
    p_metadata: { inserted, failed, by: user.id },
  } as never)
  return NextResponse.json(`Imported: ${inserted} | Failed: ${failed}${errors.length ? '\n' + errors.slice(0, 10).join('\n') : ''}`)
}
