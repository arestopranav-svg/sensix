import { requireStaff, can } from '@/lib/auth'
import { createAdminClient } from '@/lib/supabase/admin'
import { NextResponse } from 'next/server'

export async function GET() {
  const { supabase, role } = await requireStaff()
  if (!(await can(supabase, role, 'devices'))) return NextResponse.json({ error: 'forbidden' }, { status: 403 })
  const admin = createAdminClient()
  const { data } = await admin.from('devices').select('device_brands(slug), model, slug, category, os, processor, gpu, ram_gb, storage_gb, display, refresh_rate, release_info, source_ref').order('model')
  const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`
  const header = 'brand_slug,model,slug,category,os,processor,gpu,ram_gb,storage_gb,display,refresh_rate,release_info,source_ref'
  const lines = (data ?? []).map((d: any) => [
    d.device_brands?.slug, d.model, d.slug, d.category, d.os, d.processor, d.gpu,
    d.ram_gb, d.storage_gb, d.display, d.refresh_rate, d.release_info, d.source_ref,
  ].map(esc).join(','))
  return new NextResponse([header, ...lines].join('\n'), {
    headers: {
      'Content-Type': 'text/csv',
      'Content-Disposition': 'attachment; filename="devices.csv"',
    },
  })
}
