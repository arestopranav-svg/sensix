import { createClient } from '@/lib/supabase/server'
import { rateLimit, clientIp } from '@/lib/rate-limit'
import { NextResponse } from 'next/server'
import { z } from 'zod'

const schema = z.object({
  event: z.string().min(1).max(60),
  path: z.string().max(300).optional(),
  entity: z.string().max(40).optional(),
  entity_id: z.string().max(64).optional(),
})

export async function POST(req: Request) {
  const rl = await rateLimit(`analytics:${clientIp(req)}`, 120, 60_000)
  if (!rl.ok) return NextResponse.json({ ok: false }, { status: 429 })
  const parsed = schema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) return NextResponse.json({ ok: false }, { status: 400 })
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  await supabase.from('analytics_events').insert({
    ...parsed.data, user_id: user?.id ?? null,
    session_id: req.headers.get('x-session-id'),
  })
  return NextResponse.json({ ok: true })
}
