export const metadata = { title: 'Terms of Service' }
export default function Terms() {
  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-2xl font-bold">Terms of Service</h1>
      <div className="mt-4 space-y-3 text-sm text-gray-600 dark:text-gray-300">
        <p>By using SensiX you accept that settings profiles are provided as-is, without any guarantee of improved performance.</p>
        <p>Submissions must be your own work or appropriately attributed. Staff may reject any submission.</p>
        <p>SensiX is not affiliated with any game publisher or device manufacturer; all trademarks belong to their respective owners.</p>
        <p>Abuse, spam or attempts to manipulate ratings may result in account suspension.</p>
      </div>
    </div>
  )
}
