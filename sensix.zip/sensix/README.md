# SensiX — Global Gaming Sensitivity & Settings Platform

**Your Device. Your Game. Your Settings.**

SensiX is a full-stack platform for discovering and sharing gaming sensitivity, graphics and control settings tuned for specific devices. Independent platform — not affiliated with any game publisher or device manufacturer.

## Tech stack

- **Frontend/Backend:** Next.js 14 (App Router) · React 18 · TypeScript · Tailwind CSS · Lucide icons
- **Database/Auth:** PostgreSQL via Supabase (email/password, Google OAuth, phone OTP) · Row Level Security on every table
- **Hosting:** Vercel-ready

## Project structure

```
sensix/
├── supabase/
│   └── migrations/
│       ├── 001_schema.sql     # full normalized schema + RLS + triggers + audit
│       └── 002_seed.sql       # clearly-labeled SAMPLE data (games, devices, settings)
├── scripts/
│   └── make-admin.mjs         # bootstrap the first super admin (server-side only)
├── src/
│   ├── middleware.ts          # session refresh + auth redirect for /dashboard, /admin
│   ├── lib/
│   │   ├── supabase/          # server / browser / service-role clients
│   │   ├── auth.ts            # requireUser / requireStaff / can() permission checks
│   │   ├── validations.ts     # zod schemas for every mutation
│   │   └── rate-limit.ts      # Upstash Redis or in-memory fallback
│   ├── components/            # Navbar, cards, SearchBar, buttons, Pagination...
│   └── app/
│       ├── page.tsx           # homepage
│       ├── games/  devices/  search/  settings/[id]/   # public catalogue
│       ├── login/ signup/ reset-password/ auth/         # auth flows
│       ├── dashboard/         # user dashboard + submissions
│       ├── admin/             # staff panel (server-enforced RBAC)
│       └── api/               # analytics, favourites, saved, rating, CSV import/export
└── .env.example
```

## Setup

1. **Create a Supabase project** → copy URL, anon key, service-role key.
2. `cp .env.example .env.local` and fill in the values (see `.env.example` for what each is).
3. Apply database migrations, in order:
   - `supabase link --project-ref <your-project-ref>` then `supabase db push`, **or**
   - paste `supabase/migrations/001_schema.sql` then `002_seed.sql` into the Supabase SQL editor.
4. `npm install`
5. `npm run dev` → http://localhost:3000

## External credentials

| Integration | Where configured |
|---|---|
| Supabase (URL, anon key, service-role key) | `.env.local` — service-role key is **server-only**, never exposed to the browser |
| Google OAuth | Google Cloud Console → OAuth client → authorized redirect URI `https://<project>.supabase.co/auth/v1/callback`; then paste client id/secret in **Supabase Dashboard → Authentication → Providers → Google** |
| Phone OTP | **Supabase Dashboard → Authentication → Providers → Phone** (Twilio/MessageBird credentials live there; the app only calls `signInWithOtp`/`verifyOtp`) |
| Rate limiting (optional, production) | Upstash Redis → `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN` |

## Admin bootstrap (first super admin)

1. Sign up on the site normally (email or Google).
2. Run: `node scripts/make-admin.mjs you@example.com super_admin` (uses the service-role key from env).
3. No admin passwords or privileges are hardcoded or publicly registrable. Only super admins can grant super admin (enforced server-side and in RLS).

## Deployment (Vercel)

1. Push to GitHub → import repo in Vercel.
2. Add the same env vars in Vercel → Project → Settings → Environment Variables. Set `NEXT_PUBLIC_SITE_URL` to your domain.
3. Add your domain to **Supabase → Authentication → URL Configuration** (redirect URLs).
4. Deploy. `sitemap.xml` and `robots.txt` are generated automatically.

## GitHub Codespaces

Open the repo in a Codespace → `cp .env.example .env.local` → fill values → `npm install` → `npm run dev`. Port 3000 auto-forwards.

## Roles

| Role | Capabilities |
|---|---|
| super_admin | everything + manage admins/permissions + audit logs |
| admin | games, devices, settings, submissions, users |
| moderator | review/approve/reject submissions, view content |
| editor | manage approved content (games, devices, content) — no user management |
| user | browse, save, favourite, submit settings for review |

All enforcement is server-side (Next.js server actions/route handlers) **and** database-side (RLS). Hiding UI buttons is never the security model.

## Security notes

- Row Level Security enabled on every table; staff-only tables reject anonymous/authenticated reads.
- Users cannot change their own role or promote themselves (RLS `with check` + server guard).
- Every admin mutation is written to `audit_logs`.
- All mutations validated with zod; service-role key never leaves the server.
- Rate limiting on analytics and rating endpoints (add Upstash in production).
- Security headers set in `next.config.mjs`.

## Sample data

`002_seed.sql` contains clearly-labeled **sample** content (games, devices, settings profiles, banner, announcement). Device specs marked unknown are never invented. Ratings/views are real (start at zero) — no fake popularity.

## Remaining work (Phase 2)

- Dedicated admin UI for Analytics detail, Content CMS (banners/announcements), and Audit Log viewer (tables + RLS are ready).
- Search autocomplete dropdown + recent-searches persistence.
- Automated test suite (Playwright smoke tests).
