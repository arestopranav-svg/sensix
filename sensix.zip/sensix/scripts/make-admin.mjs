// BOOTSTRAP ONLY: promote the first super admin (or any staff role).
// Usage: node scripts/make-admin.mjs user@example.com super_admin
import { createClient } from '@supabase/supabase-js'

const url = process.env.NEXT_PUBLIC_SUPABASE_URL
const key = process.env.SUPABASE_SERVICE_ROLE_KEY
const [email, role = 'super_admin'] = process.argv.slice(2)
if (!url || !key) { console.error('Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY'); process.exit(1) }
if (!email) { console.error('Usage: node scripts/make-admin.mjs <email> [role]'); process.exit(1) }
if (!['editor', 'moderator', 'admin', 'super_admin'].includes(role)) { console.error('Invalid role'); process.exit(1) }

const supabase = createClient(url, key)
const { data: users, error } = await supabase.auth.admin.listUsers()
if (error) { console.error(error.message); process.exit(1) }
const user = users.users.find((u) => u.email === email)
if (!user) { console.error(`No user with email ${email}. Sign up first.`); process.exit(1) }
const { error: upErr } = await supabase.from('profiles').update({ role }).eq('id', user.id)
if (upErr) { console.error(upErr.message); process.exit(1) }
console.log(`${email} is now ${role}`)
